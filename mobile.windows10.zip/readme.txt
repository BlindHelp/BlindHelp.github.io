﻿How to Unlock Mobile Text-To-Speech Voice in Windows 10


By default, the Microsoft mobile voice is locked for using in
text-to-speech software via SAPI 5. You can unlock it with a
simple registry tweak. Download the archive, extract the file
for your language and for your version of the operating system
("mobile_x86.reg" for 32bit and "mobile_x64.reg" for 64bit),
click the right mouse button on the file's name and choose the
context menu item "Merge". The Microsoft mobile voice will
appear in the list of the available voices in Balabolka.

###

Голоса Microsoft Mobile предназначены для использования
в приложениях из магазина Windows Store. По умолчанию к голосам
нельзя обратиться при помощи функций SAPI 5. Однако, есть
простой способ решить данную проблему. Скачайте архив, извлеките
из него файл для соответствующего языка и соответствующей версии
операционной системы ("mobile_x86.reg" для 32-битной версии и
"mobile_x64.reg" для 64-битной версии), кликните правой кнопкой
мыши на имени файла и выберите пункт "Слияние" в контекстном
меню. Данные о голосе добавятся в системный реестр Windows, и
голос можно будет использовать в программе "Балаболка".

###

Chinese (Simplified, PRC):
  Microsoft Kangkang Mobile
  Microsoft Yaoyao Mobile

Chinese (Traditional, Hong Kong S.A.R.):
  Microsoft Danny Mobile
  Microsoft Tracy Mobile

Chinese (Traditional, Taiwan):
  Microsoft Yating Mobile
  Microsoft Zhiwei Mobile

English (India):
  Microsoft Heera Mobile
  Microsoft Ravi Mobile

English (United Kingdom):
  Microsoft George Mobile
  Microsoft Susan Mobile

English (United States):
  Microsoft Mark Mobile
  Microsoft Zira Mobile

French:
  Microsoft Julie Mobile
  Microsoft Paul Mobile

German:
  Microsoft Katja Mobile
  Microsoft Stefan Mobile

Italian:
  Microsoft Cosimo Mobile
  Microsoft Elsa Mobile

Japanese:
  Microsoft Ayumi Mobile
  Microsoft Ichiro Mobile

Polish:
  Microsoft Adam Mobile
  Microsoft Paulina Mobile

Portuguese (Brazil):
  Microsoft Daniel Mobile
  Microsoft Maria Mobile

Russian:
  Microsoft Irina Mobile
  Microsoft Pavel Mobile

Spanish (Mexico):
  Microsoft Raul Mobile
  Microsoft Sabina Mobile

Spanish (Spain):
  Microsoft Laura Mobile
  Microsoft Pablo Mobile

###