# Contributors #

<html lang="en">


<caption>List of Weather_Plus add-on translators</caption>

| Language localisation code | Language | Translate into | Translation by | E-mail |
| ------------- | ------------- | ------------- | ------------- | ------------- |
| ar | Arabic | Arabic | Wafik immaculate | fatma.mehanna@gmail.com |
| ___ | ___ | ___ | wafiqtaher | wafiqtaher@gmail.com |
| cs | Czech | Czech | Jiří Holzinger | jiriholz@centrum.cz |
| ___ | ___ | ___ | Tapin | tapin@wo.cz |
| de | German | German | Karl Eick | hozosch@web.de |
| es | Spanish | Spanish | Rémy Ruiz | remyruiz@gmail.com |
| ___ | ___ | ___ | Pablo Vargas | pablo.aguantelabuenamusica@gmail.com |
| fr | French | French | Rémy Ruiz | remyruiz@gmail.com |
| ___ | ___ | ___ | Michel Such | michel.such@free.fr |
| ___ | ___ | ___ | Corentin Bacqué-Cazenave | corentin@progaccess33.net |
| gl | Galician | Galician | Iván Novegil Cancelas | ivan.novegil.cancelas@gmail.com |
| it | Italian | Italian | Adriano Barbieri | adrianobarb@yahoo.it |
| pl | Polish | Polish | Zvonimir Stanecic | zvonimirek222@yandex.com |
| pt_BR | Brazilian-Portuguese | Portuguese (Portugal) | Ângelo Miguel Abrantes | ampa4374@gmail.com |
| pt_PT | Portuguese (Portugal) | Portuguese (Portugal) | Ângelo Miguel Abrantes | ampa4374@gmail.com |
| ___ | ___ | ___ | Rui Fontes | rui.fontes@tiflotecnia.net |
| ro | Romanian | Romanian | Florian Ionașcu | florianionascu@hotmail.com |
| ru | Russian | Russian | Alex Yeshanu | eshanuap@gmail.com |
| sk | Slovak | Slovak | Peter Halada | pietro4044@gmail.com |
| sr | Serbian | Croatian | Gašić Dejan (Gashich Deyan) | gasicd@gmail.com |
| uk | Ukrainian | Ukrainian | Alex Yeshanu | eshanuap@gmail.com |
