# Clipspeak

* Auteur : Damien Sykes-Lindley
* Télécharger [version de développement][1]

Clipspeak est une extension qui permet à NVDA d'annoncer automatiquement les opérations du presse-papiers (telles que couper, copier et coller), ainsi que d'autres opérations courantes d'édition telles que sélectionner tout, annuler et rétablir.
Afin d'éviter l'annonce dans des situations inappropriées, Clipspeak effectue des recherches dans le contrôle et dans le presse-papiers afin de prendre une décision éclairée quant à savoir si une telle annonce est nécessaire. Pour cette raison, les annonces de Clipspeak peuvent être inexactes.
Par défaut, les gestes de Clipspeak sont assignées à ceux couramment utilisés par les versions anglaises de Windows, C'EST À DIRE. :

* CTRL+A : Sélectionner tout
* CTRL+Z : Annuler
* CTRL+Y : Rétablir
* CTRL+X : Couper
* CTRL+C : Copier
* CTRL+V : Coller

Si ce ne sont pas les raccourcis couramment utilisés pour ces tâches sur votre version de Windows, vous devrez réassigner ces gestes dans la configuration des Gestes de commandes dans la catégorie Presse-papiers.

[1]: http://addons.nvda-project.org/files/get.php?file=cs
