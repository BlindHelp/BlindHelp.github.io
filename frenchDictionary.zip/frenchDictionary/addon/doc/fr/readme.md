# frenchDictionary

## Rechercher une définition  d'un mot dans le dictionnaire de la langue française.

### Introduction.

L'extension frenchDictionary pour NVDA permet aux utilisateurs de consulter rapidement et en forme accessibles toute définition d'un mot dans le [Dictionnaire  de la LANGUE FRANÇAISE à partir du site  [Larousse.fr](https://www.larousse.fr/).

### Mode d'utilisation.

Si un mot était sélèctionné, il va rechercher la définition du motsélèctionnné, sinon une boite de dialogue apparaitra pour vous permettre  de saisir un mot dans le champs de recherche.

Vous pouvez appuyer sur NVDA + D pour exécuter ce dictionnaire.

Vous pouvez utiliser les flèches pour naviguer dans le contenu de la fenêtre de résultat.

Si vous sélectionné accidentellement plusieurs mots et la recherche est exécutée, l'extension prendra en compte que le premier mot.

Vous pouvez fermer cette fenêtre en appuyant sur ECHAP ou ALT + F4

La combinaison de touches NVDA + D peut être personnalisé dans le menu NVDA / Préférences / Gestes de commandes, sous la catégorie "Dictionnaire français".

### Raccourcis.

Le seul raccourci pour le moment dans cette extension est la combinaison de touches NVDA + D. Son rôle est d'afficher la boîte de  dialogue pour saisir un  mot dans le champ de recherche, ainsi que de rechercher la définition du mot sélèctionnné dans le [Dictionnaire  de la LANGUE FRANÇAISE à partir du site  [Larousse.fr](https://www.larousse.fr/).