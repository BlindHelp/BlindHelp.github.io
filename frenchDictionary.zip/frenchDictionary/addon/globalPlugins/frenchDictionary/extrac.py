﻿from ui import message , browseableMessage 
from re import compile 
from urllib import request
from tones import beep 
import addonHandler 
addonHandler.initTranslation ()
def b ():beep (500 ,500)
class Extract (object):
	reg_link = compile ("<a.+?>(.+?)</a>")
	reg_firstWord = compile ("(.+?)(\s|$)")
	reg_firstSuggestion_larousse  = compile ("<h3.+?>")
	def __init__ (self , word ):
		self.word = word.strip ()
		self.word = self.reg_firstWord.search (self.word ) .group ().strip ()
		self.word_original = self.word 
		self.word = request.quote (self.word)
		self.getFromLarousse ()
	def getDataFromLarousse (self , url):
		obj  = request.urlopen (url)
		data = obj.read ().decode ("utf-8") ; obj.close ()
		return data 

	def getFromLarousse (self):
		url = "https://www.larousse.fr/dictionnaires/francais/" + self.word
		warning  = ""
		data = self.getDataFromLarousse ( url )
		haveASuggestion = True if data.find ('<h1 class="icon-question-sign">') != -1 else False 
		import api 

		if haveASuggestion :
			url = "https://www.larousse.fr" + self.reg_firstSuggestion_larousse.search (data).group ().split ("\"")[1]
			data = self.getDataFromLarousse ( url )
			warning = _("The word ' {word} ' was not found").format (word = self.word_original)
		index = data.find ("<article") 
		if index  != -1 :		
			data = data [index+ 56  :   data.index ("</article>")]
			data =self.reg_link.sub ("\\1",data)
			data = "<p><br />{warning}<br /></p><p> <br />{data}<p><br />{source} : <br />{url}</p>".format (warning = warning , data = data , url = url , source  = _("source") )
		else : data  = "<h2>" + _("Error") + " ! </h2><p> <br />" + _("{word} does not match any entry in the Larousse dictionary").format (word = self.word_original) +"</p>"
		browseableMessage  (data, "Laroussse", isHtml  = True  )
