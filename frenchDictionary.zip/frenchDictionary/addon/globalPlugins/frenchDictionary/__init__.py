﻿import globalPluginHandler , treeInterceptorHandler 
from tones import beep 
from ctypes import windll 
from gui import mainFrame , runScriptModalDialog , messageBox
import wx 
from textInfos import POSITION_SELECTION 
from api import getFocusObject 
from scriptHandler import script 
from ui import message 
from .extrac import Extract
import addonHandler 
addonHandler.initTranslation ()
summary = addonHandler.getCodeAddon ().manifest["summary"]
class GlobalPlugin (globalPluginHandler.GlobalPlugin):
	dlgBox =False 
	@script (gesture ="kb:nvda+d" , category = summary , description = _("launches the search either by displaying a dialog box, or by retrieving the selected text") )
	def script_startSearch (self, gesture = None ):
		if self.dlgBox  : b ();return self.displayTextEntry ()
		obj , useDlgBox = getFocusObject () , False 
		treeInterceptor = obj.treeInterceptor 
		if isinstance (treeInterceptor , treeInterceptorHandler.DocumentTreeInterceptor ) and not treeInterceptor.passThrough : obj = obj.treeInterceptor 
		try :
			selection = obj.selection
			if len (selection.text) <= 2 : raise ("")
		except : useDlgBox =  True 


		if useDlgBox : self.displayTextEntry ()
		else : Extract (selection.text)

	def displayTextEntry (self):
		if self.dlgBox :
			b ()
			if windll.user32.GetForegroundWindow () == self.dlgBox.Handle : self.dlgBox.Destroy ()
			else : windll.user32.SetForegroundWindow (self.dlgBox.Handle)
			return 
		self.dlgBox = TextEntryDialogBox  (mainFrame, _("Enter the word to search : ") , _("dictionary")) 
		runScriptModalDialog (self.dlgBox, self.callBack )
	def callBack (self , buttonPressed):
		value , self.dlgBox = self.dlgBox.GetValue () , False 
		if buttonPressed  == wx.ID_OK  and not value : messageBox (_("You must enter a word") , _("Failure !")) ; return self.displayTextEntry  ()
		elif buttonPressed == wx.ID_CANCEL : return 
		Extract (value)


class TextEntryDialogBox  (wx.TextEntryDialog):
	def __init__ (self, *args, **kwargs):
		super (TextEntryDialogBox, self).__init__ (*args, **kwargs)
