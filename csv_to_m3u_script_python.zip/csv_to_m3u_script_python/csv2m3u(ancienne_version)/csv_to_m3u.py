import csv
import sys

def csv_to_m3u(csv_path, m3u_path):
    """Convertit un fichier CSV en playlist M3U."""
    try:
        with open(csv_path, mode='r', encoding='utf-8') as csv_file:
            # Utilisation de DictReader pour lire les en-têtes (attend 'path' ou 'url' et 'title' ou 'name')
            reader = csv.DictReader(csv_file)
            
            with open(m3u_path, mode='w', encoding='utf-8') as m3u_file:
                # Écriture de l'en-tête standard M3U
                m3u_file.write("#EXTM3U\n")
                
                count = 0
                for row in reader:
                    # Recherche dynamique des clés courantes dans le CSV
                    # S'adapte si les colonnes s'appellent (url/path) et (title/name)
                    path = row.get('path') or row.get('url') or list(row.values())[0]
                    title = row.get('title') or row.get('name') or (list(row.values())[1] if len(row) > 1 else "Piste")
                    
                    # Écriture des balises M3U
                    m3u_file.write(f"#EXTINF:-1,{title}\n")
                    m3u_file.write(f"{path}\n")
                    count += 1
                    
        print(f"Succès ! {count} éléments convertis dans '{m3u_path}'.")
    
    except Exception as e:
        print(f"Erreur lors de la conversion : {e}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage : python csv_to_m3u.py <fichier.csv> <sortie.m3u>")
    else:
        csv_to_m3u(sys.argv[1], sys.argv[2])