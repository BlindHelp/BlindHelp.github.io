import csv
import sys

def csv_to_m3u(csv_path, m3u_path):
    """Convertit un fichier CSV (compatible PyRadio et standards) en playlist M3U propre."""
    try:
        with open(csv_path, mode='r', encoding='utf-8') as csv_file:
            # 1. Lire toutes les lignes et filtrer les commentaires
            raw_lines = csv_file.readlines()
            
        clean_lines = []
        header_found = False
        name_index = 0
        url_index = 1

        for line in raw_lines:
            stripped = line.strip()
            # Si c'est un commentaire
            if stripped.startswith('#'):
                # On regarde si c'est la ligne qui définit les colonnes (ex: # name,url,encoding...)
                if 'name' in stripped.lower() and 'url' in stripped.lower():
                    # Nettoyer le '#' et séparer pour trouver l'index exact des colonnes si besoin
                    header_cols = [col.strip().lower() for col in stripped.lstrip('#').strip().split(',')]
                    if 'name' in header_cols and 'url' in header_cols:
                        name_index = header_cols.index('name')
                        url_index = header_cols.index('url')
                        header_found = True
                continue
            
            # Ignorer les lignes vides
            if not stripped:
                continue
                
            clean_lines.append(line)

        # 2. Utiliser csv.reader sur les lignes de données nettoyées
        reader = csv.reader(clean_lines)
        
        with open(m3u_path, mode='w', encoding='utf-8') as m3u_file:
            # Écriture de l'en-tête standard M3U
            m3u_file.write("#EXTM3U\n")
            
            count = 0
            for row in reader:
                # S'assurer qu'il y a au moins assez de colonnes
                if len(row) >= 2:
                    title = row[name_index].strip()
                    url = row[url_index].strip()
                    
                    # Ignorer si le titre ou l'url est vide
                    if title and url:
                        m3u_file.write(f"#EXTINF:-1,{title}\n")
                        m3u_file.write(f"{url}\n")
                        count += 1
                        
        print(f"Succès ! {count} éléments convertis dans '{m3u_path}'.")
    
    except Exception as e:
        print(f"Erreur lors de la conversion : {e}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage : python csv_to_m3u.py <fichier.csv> <sortie.m3u>")
    else:
        csv_to_m3u(sys.argv[1], sys.argv[2])