
#include <windows.h>
#include "mpglibdll.h"

HINSTANCE    hmpglibdll;
INITMP3      InitMP3;
EXITMP3      ExitMP3;
DECODEMP3    decodeMP3;

char buf[16384];
struct mpstr mp;

int main (void)
{
	int size;
	char out[8192];
	int len,ret;

	hmpglibdll = LoadLibrary("mpglib.dll");

	if (!hmpglibdll)
		return (NO_DLL_FOUND);

	InitMP3   = (INITMP3)   GetProcAddress(hmpglibdll, TEXT_INITMP3);
	ExitMP3   = (EXITMP3)   GetProcAddress(hmpglibdll, TEXT_EXITMP3);
	decodeMP3 = (DECODEMP3) GetProcAddress(hmpglibdll, TEXT_DECODEMP3);

	InitMP3(&mp);

	while( !eof() )
	{
		len = read(0,buf,16384);
		if(len <= 0)
			break;
		ret = decodeMP3(&mp,buf,len,out,8192,&size);
		while(ret == MP3_OK)
		{
			write(1,out,size);
			ret = decodeMP3(&mp,NULL,0,out,8192,&size);
		}
	}

	ExitMP3(&mp);
	FreeLibrary(hmpglibdll);

	return (0);
}




