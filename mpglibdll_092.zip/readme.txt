
  mpglib.dll (Win32) with source (LGPL)
  Version 0.92, November 2001
  Adapted from mpglib by Martin Pesch
  (http://www.rz.uni-frankfurt.de/~pesch)

 WHAT'S THIS

  The mpglib.dll is a translation of mpg123's simplified mpglib
  into a Win32 DLL. Unlike the mpglib this mpglib.dll decodes also
  Layer 2 (like full mpg123). And it has a modified error handling:
  Where the mpglib exits if an error in the MPEG stream occurs this
  decoder returns an error message and will not halt 
  (see mpglibdll.h for more information.). There are no 3D-Now,
  Pentium or 486 instructions in this version. So this decoder
  will not run optimized.

 PLEASE NOTE

  The mpglib is originally provided by Michael Hipp under
  the GNU Lesser General Public Licence (LGPL). So even this
  modified version is provided under the LGPL (see lgpl.txt).
  You find the mpg123 project at http://www.mpg123.de. I used the
  mpglib with optimized Huffman tables from the Lame project
  wich is reachable under http://www.sulaco.org/mp3.
