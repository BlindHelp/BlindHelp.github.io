# radio station search

## Rechercher les liens directs d'écoute d'une radio

### Introduction.

Comme son nom l'indique cette extension est pour rechercher des stations de radio afin d'avoir les liens directs d'écoute de ces stations de radio puis les mettre  dans votre lecteur favori afin de les écouter ultérieurement.

Vous pouvez également coller le lien dans un document texte et changer l'extension en m3u, et hop voilà votre radio lu par votre lecteur préféré .

Nous avons également la possibilité de lire cette radio que nous venons de trouver à l'aide d'un lecteur audio intégré à l'extension. Ci-dessous, je vais expliquer cela avec plus de détails.

### Mode d'utilisation.

Avant d'effectuer une recherche d'un lien d'écoute d'une station de radio avec cette extension, vous devez la configurer en premier!

## Paramètres recherche de radio

À partir du menu Préférences -> Paramètres -> recherche de radio ouvre un panneau pour configurer les options suivantes:

La première chose que nous trouvons c'est l'élément appelé:  
`Extraire les données De : onLineRadioBox`  

Dans cette liste  déroulante  Nous avons cette seule option pour le moment disponible.

Si nous faisons Tabulation  nous trouvons  Ici deux boutons radio, donc, vous pouvez choisir entre:

`affiche le résultat de votre recherche Dans le tampon virtuel de NVDA`  
(configuration par défaut)  

`affiche le résultat de votre recherche Dans votre navigateur par défaut`  
(la configuration doit être effectuée par l'utilisateur)  

Si nous faisons une fois de plus Tabulation vient ensuite un potentiomètre  pour configurer le volume du lecteur audio intégré lors de la  consultation de résultat de votre recherche dans votre navigateur par défaut.

Cette option est un potentiomètre qui va de 0 à 100 - 0 étant le volume le plus bas et 100 le plus élevé.

Notez que ce lecteur audio n'est pas présent lorsque vous envisagez la consultation dans le tampon virtuel de NVDA.

`Lecteur audio: Niveau de volume par défaut: 10`  
Étant de 10 la valeur de volume configurée par défaut dans l'extension.  

Ce potentiomètre   va de 0 à 100, nous pouvons utiliser les flèches gauche ou droite et les flèches haut et bas pour augmenter et diminuer le volume par tranche de 1 à 1, les touches début pour le mettre à 100 et fin pour le mettre à 0, les touches page précédente et page suivante pour augmenter et diminuer le volume par tranche de 10 à 10

Selon la valeur configurée, cela sera utilisé lors de l''écoute de la radio choisie lors de la recherche dans votre navigateur par défaut.

Ensuite, si nous faisons une fois Tabulation, vous devez appuyer sur le bouton OK pour sauvegarder vos paramètres de l'extension recherche de radio.

Nous avons aussi deux boutons, Annuler et Appliquer

Si nous faisons Annuler, ou si nous appuyons sur la touche Échap tout les paramètres  seront perdues et rien ne sera sauvegardé.

Si nous faisons  Appliquer, les paramètres prennent effet immédiatement sans fermer le dialogue.

### Raccourcis de l'extension:

* "affiche la boîte de dialogue Préférences"; Sans raccourci attribué. Il peut être ajouté à partir  du dialogue Gestes de commande dans la catégorie "recherche de radio", associé à la commande: "affiche la boîte de dialogue Préférences". 
* "affiche une boîte de dialogue qui vous permet d'entrer une recherche"; NVDA+e (clavier, toutes les dispositions); Raccourci attribué par défaut. Il peut être personnalisé à partir  du dialogue Gestes de commande dans la catégorie "recherche de radio", associé à la commande: "affiche une boîte de dialogue qui vous permet d'entrer une recherche". 

Rappelez-vous que la combinaison de touches ne soit pas assignée  à une autre extension ou ne se chevauchent pas avec l'une des applications que nous utilisons.

## Comment effectuer une recherche de radio?

À savoir que nous allons  extraire des données en recherchant à partir de [onLineRadioBox](https://onlineradiobox.com/)

Lorsque vous appuyer sur le raccourci NVDA + E, vous afficher une boîte de dialogue qui vous permet de saisir dans le champs d'édition indistinctement des majuscules ou des minuscules contenant le nom d'une station de radio, ensuite appuyer sur le bouton OK pour lancer la recherche, et il nous donnera le résultat contenant ce que nous avons tapé. Peu importe le type d'affichage que vous avez choisi.

Note: Vous pouvez également appuyer sur la touche Entrée après la saisie d'une recherche sur ledit champ. Par conséquent, cette action serait la même chose que si on avait appuyé sur le bouton OK.

Lors de la recherche  d'une radio se jouera un son pour nous avertir que la recherche est en cours...

Cela ne change que la manière dont les résultats sont présentés selon l'option choisi sous forme de bouton radio lors de la configuration dans les préférences de l'extension. Je vais résumer ces deux types d'affichage ci-dessous.

## Comment sont affichées les résultats  dans le tampon virtuel de NVDA?

Si vous avez laissé le bouton radio appelée:  
`affiche le résultat de votre recherche Dans le tampon virtuel de NVDA`  
Vous aurez les résultats  affichés dans le tampon virtuel de NVDA.  
Ce bouton radio contenant ladite option est coché par défaut.  

Lorsque l'un des deux boutons radio est activé, l'autre est désactivé.

Lorsque vous obtenez les résultats vous trouverez le nom de la station de radio, l'URL d'écoute et d'autres informations pertinentes liée à la station de radio sur un tampon virtuel de NVDA. Cela sera expliqué plus loin.

Vous pouvez utiliser les flèches pour naviguer dans le contenu de la fenêtre de résultat.

Appuyez sur la lettre h pour naviguer de titre en titre, avec maj + h, on retourne au titre précédent.

Lorsque vous faites NVDA+t, dans  la fenêtre du tampon virtuel de NVDA annoncera le nombre de stations suivi  du nombre de résultats.

Le premier résultat est toujours montré dans un  titre niveau 1. Ce titre contient le nom de la station que vous avez saisie dans le champ de recherche, par exemple, france info.

Vous trouverez ci-dessous une brève description de ladite station.

Puis ensuite vient le lien d'écoute.

Ce lien n'est pas cliquable, donc vous pouvez seulement le copier puis l'utiliser dans votre lecteur préféré  afin de lire cette station de radio plus tard.

Ci-dessous vous verrez d'autres résultats en fonction de votre recherche, par exemple, si vous avez saisie france info, la partie du nom france et info sera inclus dans le cadre des résultats toujours dans un  titre niveau 1, accompagné de sa brève description et de son lien respectif.

Comme vous l'avez vu ici, c'est la façon dont les résultats  sont affichés dans le tampon virtuel de NVDA lors de la recherche à partir du site [onLineRadioBox](https://onlineradiobox.com/)

Comme je l'ai dit précédament dans ce tampon virtuel, le contenu de votre recherche sera affiché seulement avec les éléments cités ci-dessus, donc, le lecteur audio n'est pas inclus dans ce tampon virtuel de NVDA, sauf si vous utilisez le bouton radio ci-dessous.

Vous pouvez fermer cette fenêtre en appuyant sur ECHAP ou ALT + F4

## Comment sont affichées les résultats  dans votre navigateur par défaut?

Si vous avez laissé le bouton radio appelée:  
`affiche le résultat de votre recherche Dans votre navigateur par défaut`  
Vous aurez les résultats  affichés de votre recherche dans votre navigateur par défaut.  
Ce bouton radio contenant ladite option n'est pas coché, afin que cette option soit fonctionnelle, la configuration doit être effectuée par l'utilisateur comme décrit ci-dessus.  

Lorsque l'un des deux boutons radio est activé, l'autre est désactivé.

Lorsque vous obtenez les résultats vous trouverez le nom de la station de radio, l'URL d'écoute et d'autres informations pertinentes liée à la station de radio sur une page HTML y compris des boutons, titres et liens cliquables. Cela sera expliqué plus loin.

Appuyez sur la lettre b pour naviguer de bouton en bouton, avec maj + h, on retourne au bouton précédent.

Ces boutons sont disponibles au début de la page HTML, une partie de ces boutons permet de contrôler le lecteur audio.

Vous pouvez utiliser les flèches pour naviguer dans le contenu de la fenêtre de résultat.

Appuyez sur la lettre h pour naviguer de titre en titre, avec maj + h, on retourne au titre précédent.

Lorsque vous faites NVDA+t, annoncera le titre de la station de radio suivi de sa position sur la page.  
Pendant ma recherche j'avais  saisie  france info,  le titre de cette page HTML est affichée comme nom:  
`France Info, 1 Of 19`  
C'est-à-dire que nous sommes sur le résultat 1 sur 19  
Si vous écoutez une autre station de radio sur cette page, le nom du titre puis le nombre de la position de la station de radio changera, par exemple:  
`France Bleu, 9 Of 19`  
C'est-à-dire que nous sommes sur le résultat 9 sur 19  
Et ainsi de suite...  
Jusqu'à ce que nous tombons à nouveau sur le résultat 1 sur 19  

Au début de la page HTML, nous tomberons sur les suivants boutons:
 
`bouton next`  
Lorsque vous appuyez sur ce bouton ou sur son raccourci attribué  selon le navigateur Web utilisé vous permettra de lancer la lecture de la suivante radio.  
`bouton previous`  
Lorsque vous appuyez sur ce bouton ou sur son raccourci attribué  selon le navigateur Web utilisé vous permettra de lancer la lecture de la radio précédente.  
`bouton copy the link`  
Lorsque vous appuyez sur ce bouton ou sur son raccourci attribué  selon le navigateur Web utilisé vous permettra de copier l'URL de la radio en cours de lecture dans le presse-papiers afin de le Coller  dans votre lecteur favori afin de l'écouter ultérieurement.  
Vous pouvez également coller le lien dans un document texte et changer l'extension en m3u, et hop voilà votre radio lu par votre lecteur préféré .  

Quelques touches de commandes utiles pour naviguer à travers le lecteur audio ou stations de radio trouvés sur cette page HTML:

`Play /pause : Alt+ P`  
Lorsque vous appuyez sur  le raccourci Alt + P nous permettra de lancer la lecture de la radio ou la mettre en pause à tout moment.  
`Mute /Unmute : Alt+3`  
Lorsque vous appuyez sur  le raccourci Alt + 3  coupera le son, ou remettra le son et vice versa pendant la lecture.  
`Volume Down / Up : Alt + 1 /Alt + 2`  
Lorsque vous appuyez sur  le raccourci Alt + 1 diminuera le volume  et lorsque vous appuyez sur  le raccourci Alt + 2 augmentera le volume pendant la lecture.  
`previous / next station : Alt + 4 / Alt+ 5`  
Lorsque vous appuyez sur  le raccourci Alt + 4 lira la station de radio précédente et lorsque vous appuyez sur  le raccourci Alt + 5 lira la suivante station de radio.  

Ensuite nous tomberons  sur l'états  des boutons qui contrôlent la lecture, et les informations sur le pourcentage de charge du tampon, le niveau de volume, etc:

`bouton Lecture`  
Ce bouton changera de nom de "Lecture" en "Pause" lorsque nous venons de mettre en lecture la radio que nous voulons écouter.  
`bouton Pause`  
Ce bouton changera de nom de "Pause" en "Lecture" lorsque nous venons de mettre en pause la radio que nous écoutions.  
`Chargement... : 100%`  
Cette indication nous informe que le tampon de la radio a chargé à 100%  
`Position Potentiomètre 0:00`  
Cette indication nous informe le temps d'écoute d'une radio, par exemple:  
`Position Potentiomètre  0:42 / 33:25`  
`bouton Muet`  
Ce bouton changera de nom de "Muet" en "Audible" lorsque nous venons de mettre en sourdine la radio que nous écoutions.  
`bouton Audible`  
Ce bouton changera de nom de "Audible" en "Muet" lorsque nous venons de remettre le son à la radio que nous écoutions.  
`Volume Potentiomètre 30`  
C'est la valeur que nous avons configuré pour le lecteur audio dans les préférences de l'extension.  
Bien sûr, nous pouvons changer cette valeur manuellement dans ce potentiomètre, pour cela vous devrez appuyer sur la barre d'espace ou la touche Entrée afin de passer manuellement  NVDA en mode formulaire, puis nous pouvons utiliser les flèches gauche ou droite et les flèches haut et bas pour augmenter et diminuer le volume par tranche de 10 à 10.  
Appuyer sur la touche "échap" repassera NVDA en mode navigation.  
Ce changement n'est que temporaire, par exemple si vous  souhaitez rafraîchir  cette page, le niveau de volume que vous avez configuré dans les préférences de l'extension est à nouveau remis sur ce potentiomètre.  

Sous ce potentiomètre  vous trouverez le  premier résultat qui est toujours montré dans un  titre cliquable niveau 1. Ce titre contient le lien suivi du nom de la station que vous avez saisie dans le champ de recherche, par exemple, france info.

Vous pouvez cliquer ici en appuyant sur la barre d'espace ou la touche Entrée pour écouter la radio grâce au lecteur audio intégré sur cette page HTML.

Vous trouverez ci-dessous une brève description de ladite station.

et à la fin de la page HTML, vous aurez le lien d'écoute.

Ce lien n'est pas cliquable, donc vous pouvez seulement le copier puis l'utiliser dans votre lecteur préféré  afin de lire cette station de radio plus tard.

Ci-dessous vous verrez d'autres résultats en fonction de votre recherche, par exemple, si vous avez saisie france info, la partie du nom france et info sera inclus dans le cadre des résultats toujours dans un  titre cliquable niveau 1, accompagné de sa brève description et de son lien respectif à la fin de la page HTML.

Comme vous l'avez vu ici, c'est la façon dont les résultats  sont affichés Dans votre navigateur par défaut lors de la recherche à partir du site [onLineRadioBox](https://onlineradiobox.com/)

Notez que les résultats sur la page HTML sont affichés dans votre navigateur par défaut seulement avec les éléments cités ci-dessus, y compris   le lecteur audio, tandis que les résultats dans le tampon virtuel de NVDA sont affichés Sans aucun lien cliquable, pas de boutons, aucun lecteur audio.

Vous pouvez fermer cette fenêtre en appuyant sur ALT + F4

Profitez de cette extension radio station search pour NVDA!