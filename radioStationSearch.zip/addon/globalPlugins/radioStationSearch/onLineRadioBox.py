﻿import globalPluginHandler 
from addonHandler import initTranslation , getCodeAddon
initTranslation ()
from ui import message , browseableMessage 
import config
from os import startfile 
from tempfile import tempdir
from os.path import join, dirname
from string import capwords
from re import compile, MULTILINE
from urllib import request, parse 
from tones import beep
def b ():beep (500 , 500 )
class OnLineRadioBox ():
	resultForNavigator = "<p><br /> </p><h1 indice = '{index}' onclick = 'playStream(this)' value = '{stream}' >{h1}</h1><p><br />{infos}.<br /></p>"
	footer_virtualBuffer =_("search performed on (onLineRadioBox): {url}")
	footer_navigator = _("search performed on  :<br /><a href='{url}'>onLineRadioBox</a>")
	text_notResult = _ ("""sorry, " {query} " did not yield any results. """)
	dialogTitle = _("Number of stations: {numberOfResult}")
	reg_volume = compile ("\d\.\d+")
	reg_title  = compile ("<h2>.+?(\d+)</h2>")
	reg_info = compile ("<a.+?</a>")
	reg_stream  = compile ('stream="(.+?)"')
	reg_build_h1 = compile ("<figcaption.+?>(.+?)<")
	reg_data =compile ('<li class="stations__station".+?</button>' )
	resultForVirtualBuffer  = "<p><br /> </p><h1>{h1}</h1><br /><p>{infos}</p><br /><p>{stream}</p>"

	def __init__ (self , query ):
		self.query = parse.unquote (query )
		self.url = url = "https://onlineradiobox.com/search?q={query}".format (query  = query)
		obj = request.urlopen (url)
		data  =obj.read ().decode ()
		start = data.index ('id="stations"' ) ; end  = data.index ("</section>" , start );
		self.numberOfResult = self.reg_title.search (data)
		self.numberOfResult = 0 if self.numberOfResult is None else  self.numberOfResult.group (1)
		self.data =data [ start : end ]
	def extract (self  ):
		if not self.numberOfResult  : return browseableMessage (self.text_notResult.format ( query = self.query ) , _("failure !") , isHtml =True)
		display_in_navigator  = config.conf["radioStationSearch"]["displayMode"]
		data , stations = self.data , ""
		data =data.replace ("\n"," ").replace ("\t"," ").replace ("\r","")
		index =0
		(footer, stationInfo)   = (self.footer_navigator, self.resultForNavigator )  if display_in_navigator else (self.footer_virtualBuffer , self.resultForVirtualBuffer)

		for station in self.reg_data.findall (data): 
			h1 = capwords (self.reg_build_h1.search (station).group (1) )
			stream = self.reg_stream.search (station).group (1)
			infos = [info.split ("<")[-2] for info in self.reg_info.findall   (station)]
			infos = [info[info.rindex (">") +1 :] for info in infos ]
			infos = ",".join ([info for info in infos if info and len (info.strip ()) ])
			stations += stationInfo.format ( stream = stream , h1 =h1  , infos = infos , index = index )
			index+=1

		stations += "<p><br />" + footer.format ( url = "<br />" + self.url)+ "</p><br />"
		if display_in_navigator  :
			self.displayInBrowser(stations)
		else :
			browseableMessage (stations,self.dialogTitle.format ( numberOfResult = self.numberOfResult), isHtml =True)
	def displayInBrowser(self,stations):
		path = join (dirname (__file__), "radioStationSearch.html")
		with open (path , "r" , encoding = "utf-8") as file : 
			data =file.read ().replace ("{stations}" , stations)
		#set volume :
		volume = str (config.conf["radioStationSearch"]["audioPlayerVolume"]/100)
		data = self.reg_volume.sub (volume , data)
		path  = join (tempdir , "radioStationSearch.html")
		with open (path , "w" , encoding = "utf-8") as file : file.write (data)
		startfile (path )
		b ()