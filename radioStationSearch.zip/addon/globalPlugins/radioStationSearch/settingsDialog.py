﻿from gui import SettingsPanel , guiHelper, nvdaControls
from tones import beep 
import config
import wx 
import addonHandler 
# For translation
addonHandler.initTranslation()

import config
confSpec = { 
"webSite" : "string(default = radio.fr)",
"audioPlayerVolume" : "integer(default = 10)",
"displayMode" : "integer(default = 0)"
}
config.conf.spec["radioStationSearch"] = confSpec 


def b ():beep (500,500)
class RadioStationSearch_settings (SettingsPanel):
	title =addonHandler.getCodeAddon ().manifest["summary"]
	def makeSettings (self, settingsSizer):
		settingsSizerHelper = guiHelper.BoxSizerHelper ( self, sizer = settingsSizer )
		stationBoxLabel = _("Extract data… ")
		stationBoxSizer = wx.StaticBoxSizer ( parent = self , orient = wx.HORIZONTAL , label = stationBoxLabel )
		stationBox = stationBoxSizer.GetStaticBox ()
		stationChoiceGroupSizer  = guiHelper.BoxSizerHelper  ( parent = stationBox , sizer =stationBoxSizer)
		settingsSizerHelper.addItem (stationBoxSizer )


		stationChoiceLabel  = _("&From :")
		stationChoice = ( "onLineRadioBox" , "radio.fr" )
		self.stationChoice = stationChoiceGroupSizer.addLabeledControl  (stationChoiceLabel ,  wx.Choice , choices = stationChoice)
		opt_webSite = config.conf["radioStationSearch"]["webSite"]
		iSelection = 0 if str (opt_webSite) not in stationChoice else stationChoice.index (opt_webSite)
		self.stationChoice.SetSelection (iSelection)
		#staticbox for display  mode 
		displayModeLabel = _("display the result of your search :")
		displayModeBoxSizer = wx.StaticBoxSizer (wx.HORIZONTAL , self , label  = displayModeLabel )
		displayModeBox = displayModeBoxSizer.GetStaticBox ()
		displayModeGroupSizer  = guiHelper.BoxSizerHelper ( self , sizer = displayModeBoxSizer )
		settingsSizerHelper.addItem (displayModeGroupSizer )
		displayModeChoices = ( _("In &NVDA's own virtual buffer") , _("In your default &browser") )
		self.displayModeChoice = wx.RadioBox (displayModeBox , wx.ID_ANY , choices = displayModeChoices )
		self.displayModeChoice.SetSelection ( config.conf["radioStationSearch"]["displayMode"])
		displayModeGroupSizer.addItem (self.displayModeChoice)

		#staticBox : adjust the volume of the web page
		audioPlayerVolumeValue = config.conf["radioStationSearch"]["audioPlayerVolume"]
		audioLabel  = _("Audio player")
		audioBoxSizer  = wx.StaticBoxSizer ( orient = wx.HORIZONTAL , parent = self , label = audioLabel )
		audioBox = audioBoxSizer.GetStaticBox ()
		audioGroupSizer = guiHelper.BoxSizerHelper  (parent  = self , sizer = audioBoxSizer)
		settingsSizerHelper.addItem (audioBoxSizer)
		volumeLabel = _("Default &volume level:")
		self.audioPlayerVolume = audioGroupSizer.addLabeledControl (volumeLabel , nvdaControls.EnhancedInputSlider , value  = audioPlayerVolumeValue  , minValue = 0 , maxValue = 100 , style = wx.SL_VERTICAL )

	def onSave (self):
		config.conf["radioStationSearch"]["webSite"] = self.stationChoice.GetStringSelection ()
		config.conf["radioStationSearch"]["audioPlayerVolume"] = self.audioPlayerVolume.GetValue ()
		config.conf["radioStationSearch"]["displayMode"] = self.displayModeChoice .GetSelection ()
