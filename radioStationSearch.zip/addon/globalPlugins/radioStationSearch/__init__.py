﻿from tones import beep 
import config
from . settingsDialog import RadioStationSearch_settings 
from .radioFr import RadioFr 
from. onLineRadioBox  import OnLineRadioBox
from ui import message,browseableMessage
from ctypes import windll
from wx import TextEntryDialog, ID_OK, ID_CANCEL, ICON_WARNING , CallAfter 
from gui import runScriptModalDialog , mainFrame , messageBox, NVDASettingsDialog
from base64 import b64decode
from scriptHandler import script 
import globalPluginHandler 
import urllib.parse
from os.path import dirname, join
import sys
from re import compile 
from addonHandler import initTranslation , getCodeAddon
initTranslation ()
summary =getCodeAddon ().manifest["summary"]
def b ():beep (500,500)
class GlobalPlugin (globalPluginHandler.GlobalPlugin):
	TextEntryDialogBox = False 
	reg_urls =compile ("\"streams\":\[\{\"url\":\"(.+?)\"")
	reg_stationName = compile ("\"name\":\"(.+?)\"")
	reg_stationCity = compile ("\"city\":\"(.+?)\"")
	reg_stationCountry = compile ("\"country\":\"(.+?)\",")
	reg_adParams = compile ("\"adParams\".+?&amp;(.+?)\",\"hideReferer\"")
	reg_homePageUrl = compile ("\"homepageUrl\":\"(.+?)\",")
	reg_stationDescription = compile ("\"description\":\"(.+?)\",")
	noAvailableInformation = _("no available information")
	def terminate (self):
		try :NVDASettingsDialog.categoryClasses.remove (RadioStationSearch_settings)
		except : pass 
	def __init__ (self, *args, **kwargs):
		super (GlobalPlugin, self).__init__(*args, **kwargs)
		self.loadLib ()
		NVDASettingsDialog.categoryClasses.append (RadioStationSearch_settings)

		
	def loadLib (self):
		path  =join (dirname (__file__),"lib")
		sys.path.append (path)
		from requests_html import HTMLSession
		self.HTMLSession =HTMLSession ()
		sys.path.remove (path)
	@script ( category = summary , description = _("displays the preferences dialog") )
	def script_activateAddonSettingsDialog ( self , gesture):
		CallAfter (self.onAddonSettingsDialog )
	def onAddonSettingsDialog (self):
		mainFrame._popupSettingsDialog(NVDASettingsDialog, RadioStationSearch_settings )

	@script (gesture = "kb:nvda+e" , description =_("displays a dialog box that allows you to enter a search."), category =summary)
	def script_startResearch (self,gesture = None ):

		if not self.TextEntryDialogBox  : 
			self.TextEntryDialogBox = TextEntryDialogBox (mainFrame , _("keyword :"),_("radio station search"))
			return runScriptModalDialog (self.TextEntryDialogBox, self.callBack )
		else : dialogBox_handle, foregroundWindow_handle  = self.TextEntryDialogBox.Handle , windll.user32.GetForegroundWindow ()
		if dialogBox_handle == foregroundWindow_handle : self.TextEntryDialogBox.Close ()
		else :windll.user32.SetForegroundWindow (dialogBox_handle)
	def showResult (self, query , urls ):
		text , urls, query  = "", urls[:10 ], query 
		for url in urls :
			text = text + self.getInfo_radioStation(url)
		query = _("{0} station radio found for '{1}'.").format (str (len (urls)), query)
		browseableMessage (text, title = query, isHtml =True)
	def getInfo_radioStation (self, url,):
		genre, topic, languages, GeographicalLocation =[],[],[], [""]*4
		request = self.HTMLSession.get (url)
		text = request.html.find ("script")[10].raw_html.decode ()
		stationUrls =[url for url in self.reg_urls.findall (text)]
		stationUrls = "<br />".join (stationUrls)
		stationUrls =_("direct listening link") +":<br />{0}".format (stationUrls)
		stationName =self.reg_stationName.search (text).groups()[0]
		homePageUrl =self.reg_homePageUrl.search (text).groups ()[0]
		homePageUrl = _("Home page Url")+" : {0}".format ("<br />"+homePageUrl)
		stationDescription  = self.reg_stationDescription.search (text)
		stationDescription = self.noAvailableInformation  if stationDescription is None else stationDescription.groups ()[0].replace ("\\r\\n","<br />")
		stationDescription =_("Description :{0}").format ("<br /><br />"+stationDescription)
		adParams = self.reg_adParams.search (text).groups ()[0].replace ("="," : ").split ("&amp;")
		for index  in range (len (adParams)-1,-1,-1):
			indexText = adParams[index]
			if indexText.startswith ("genre") : 
				genre.append (indexText[indexText.index (":")+2:])
				adParams.pop (index)
			elif indexText.startswith ("languages") : 
				languages.append (indexText[indexText.index (":")+2:])
				adParams.pop (index)
			elif indexText.startswith ("topic") : 
				topic.append (indexText[indexText.index (":")+2:])
				adParams.pop (index)
			elif indexText.startswith ("st_") :
				adParams.pop (index)
				if indexText.startswith ("st_cont") : GeographicalLocation [0] = indexText[indexText.index (":")+2:]
				elif indexText.startswith ("st_country") : GeographicalLocation [1] = indexText[indexText.index (":")+2:]
				elif indexText.startswith ("st_region") : GeographicalLocation [2] = indexText[indexText.index (":")+2:]
				elif indexText.startswith ("st_city") : GeographicalLocation [3] = indexText[indexText.index (":")+2:]
			elif indexText.startswith ("type") or indexText.startswith ("station") : adParams.pop (index)
			elif indexText.startswith ("family") : adParams[index] = _("family{0}").format (indexText[indexText.index(":"):])


		GeographicalLocation = [e for e in GeographicalLocation if e ]
		genre =_("genre : {0}").format (",".join (genre) if genre else self.noAvailableInformation )
		topic = _("topic : {0}").format (",".join (topic) if topic else self.noAvailableInformation )
		languages = _("languages : {0}").format (",".join (languages))
		adParams.insert (0,genre)
		adParams.insert (1 , ",".join (GeographicalLocation) )
		adParams.append (languages)
		adParams.append (topic)
		adParams ="<li>".join (adParams)

		return """<div><p><br /></p>
<h1>{0}</h1><p></p>
		<p><br />{1}</p>
<p><br />{2}</p>
<p><br />{3}</p>
<p><br /></p>
<ul><li>{4}</li></ul>
<p><br /></p>
		</div>""".format (
		stationName,
		stationUrls,
homePageUrl,
		stationDescription,
adParams
)
		

	def retrieveURLSList (self, query ):
		url ="https://www.radio.fr/search?q={0}".format (query)
		hrefs =[]
		response  =self.HTMLSession.get (url)
		for objHref  in response.html.xpath ("//h1[1]/following::a[contains (./@href , '/s/')]") :
			hrefs.append (objHref.absolute_links.pop ())
		return hrefs
	def callBack (self, buttonCancelIsPressed):
		query = urllib.parse.quote (self.TextEntryDialogBox.Value )
		if buttonCancelIsPressed == ID_CANCEL : return
		elif not query :  
			messageBox  (_("You did not enter a keyword") , _("Failure"), style =ICON_WARNING    ) 
			self.TextEntryDialogBox =False 
			return self.script_startResearch()
		webSite  = config.conf["radioStationSearch"]["webSite"]
		if webSite == "onLineRadioBox":
			OnLineRadioBox ( query).extract ()
		elif webSite == "radio.fr" :
			browseableMessage ( message = "la recherche sur radio.fr est pour l'instant désactivé"  , title = "information" , isHtml =False)
		#urls = self.retrieveURLSList(query)
		#self.showResult (query, urls)


class TextEntryDialogBox  (TextEntryDialog):
	def __init__ (self, *args, **kwargs):
		super (TextEntryDialogBox, self).__init__ (*args, **kwargs)