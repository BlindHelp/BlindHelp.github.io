﻿from tones import beep 
import urllib
def b ():beep (500 , 500 )
from ui import   message, browseableMessage 
import wx 
class RadioFr ():
	def __init__ (self, HTMLSession , query ): 
		self.url = url ="http://www.radio.fr/search?q={0}".format (query)
		data =urllib.request.urlopen (url)
		

	def extract (self):
		print (self.url)
		b()