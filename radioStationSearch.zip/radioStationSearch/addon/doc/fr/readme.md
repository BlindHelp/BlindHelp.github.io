# radio station search

## Rechercher les liens directs d'écoute d'une radio

### Introduction.

Comme son nom l'indique cette extension est pour rechercher des stations de radio afin d'avoir les liens directs d'écoute de ces stations de radio puis les mettre  dans votre lecteur favori afin de les écouter ultérieurement.

Vous pouvez également coller le lien dans un document texte et changer l'extension en m3u, et hop voilà votre radio lu par votre lecteur préféré .

### Mode d'utilisation.

Lorsque vous appuyer sur le raccourci NVDA + E vous afficher une boîte de dialogue qui vous permet de saisir le titre d'une station de radio dans le champs d'édition prévue à cette effet puis Une fois finalisé appuyer sur Entrée pour lancer la recherche.

Lorsque vous obtenez les résultats, vous trouverez le nom de la station, l'URL d'écoute, le lien de la page d'accueil de la radio et d'autres informations pertinentes liée à la station de radio, par exemple, le pays, la langue, la description, etc, si disponible.

Vous pouvez utiliser les flèches pour naviguer dans le contenu de la fenêtre de résultat.

Vous pouvez fermer cette fenêtre en appuyant sur ECHAP ou ALT + F4

La combinaison de touches NVDA + E peut être personnalisé dans le menu NVDA / Préférences / Gestes de commandes, sous la catégorie "recherche de radio".

### Raccourcis.

Le seul raccourci pour le moment dans cette extension est la combinaison de touches NVDA + E. Son rôle est d'afficher la boîte de  dialogue pour saisir le titre d'une station dans le champ de recherche.