# Diccionarios

<br>
## Información
* Autores: Rui Fontes, Ângelo Abrantes y Abel Passos do Nascimento Jr.
* Actualizado el 19/11/2021
* Descargar [versión estable][1]
* Compatibilidad con NVDA: versión 2019.3 y posteriores

<br>
## Presentación
Este complemento proporciona una manera rápida de acceder, por el momento a 21 diccionarios:

* Inglés-portugués y portugués-inglés;
* Francés-portugués y portugués-francés;
* Alemán-portugués y portugués-alemán;
* Italiano-portugués y portugués-italiano;
* Español-portugués y portugués-español;
* Inglés-español;
* Inglés (Concise Oxford dictionary);
* Portugués (definiciones) (en portugués);
* Portugués (sinónimos) (en portugués);
* Inglés (sinónimos);
* Español (RAE);
* Química (en portugués);
* Medicina (en portugués);
* Filosofía de Nicola Abbagnano (en portugués);
* Psicología de Raul Mesquita y otros (en portugués);
* Informática (en portugués).

<br>
Para no sobrecargar el complemento, sólo los diccionarios en inglés, portugués y ambos a la vez están disponibles en el complemento.

El resto se pueden descargar desde el propio complemento.

Estamos abiertos a incluir otros diccionarios, por lo que si deseas añadir alguno, contacta con uno de los autores.

<br>
## Atajos
La orden para llamar al complemento es control+shift+f6.

Es posible modificarla desde el diálogo Gestos de entrada, en la categoría Diccionarios.

<br>
## Actualización automática

Este complemento incluye funciones de actualización automática.

Se comprobará si hay una nueva versión cada vez que se inicie NVDA.

Si no deseas este comportamiento, ve a NVDA, Preferencias, Opciones, y desmarca la casilla que encontrarás en la categoría del complemento.

<br>
## Registro de cambios

### Versión 21.11
* Se han añadido más diccionarios;
* Cambiado el procedimiento de búsqueda para que no sea sensible a mayúsculas;
* Cambiada la presentación de resultados. Ahora permite elegir buscar de nuevo, copiar el resultado o salir;
* El complemento sólo se proporciona con los diccionarios en inglés, portugués y ambos idiomas. Es posible descargar el resto desde un botón en la interfaz;
* Se alojan los diccionarios en www.tiflotecnia.net.

### Versión 21.10
* Versión inicial.

[1]: https://github.com/ruifontes/Dictionaries/releases/download/21.11/dictionaries-21.11.nvda-addon
