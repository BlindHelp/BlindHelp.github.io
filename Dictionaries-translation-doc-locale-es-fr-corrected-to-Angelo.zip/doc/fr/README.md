# Dictionnaires

<br>
## Informations
* Auteurs: Rui Fontes, Ângelo Abrantes et Abel Passos do Nascimento Jr.
* Mis à jour le 19/11/2021
* Télécharger [version stable][1]
* Compatibilité NVDA: version 2019.3 et ultérieure

<br>
## Présentation
Cette extension fournit un moyen rapide d'accéder, pour le moment à 21 dictionnaires:

* Anglais-portugais et Portugais-anglais;
* Français-portugais et Portugais-français;
* Allemand-portugais et Portugais-allemand;
* Italien-portugais et Portugais-italien;
* Espagnol-portugais et Portugais-espagnol;
* Anglais-espagnol;
* Anglais (Concise Oxford dictionary);
* Portugais (définition) (en portugais);
* Portugais (synonyme) (en portugais);
* Anglais (synonyme);
* Espagnol (RAE);
* Chimie (en portugais);
* Médical (en portugais);
* Philosophie de Nicola Abbagnano (en portugais);
* Psychologie de Raul Mesquita et autres (en portugais);
* Informatique (en portugais).

<br>
Pour ne pas surcharger l'extension, seuls les dictionnaires en anglais, portugais et les deux en même temps sont disponibles dans l'extension.

Le reste peut être téléchargé à partir de l'extension elle-même.

Nous sommes ouverts à inclure d'autres dictionnaires, donc si vous souhaitez ajouter quelques-uns, contactez l'un des auteurs.

<br>
## Raccourcis
La commande afin d'invoquer l'extension est control+maj+f6.

Elle est possible de la modifier à partir de la boîte de dialogue Gestes de commandes, sous la catégorie Dictionnaires.

<br>
## Mise à jour automatique

Cette extension comprend des fonctions de mise à jour automatiques.

Il sera vérifié s'il y a une nouvelle version à chaque démarrage de NVDA.

Si vous ne voulez pas ce comportement, aller dans le menu NVDA, Préférences, Paramètres et décochez la case sous la catégorie de l'extension.

<br>
## Journal des changements

### Version 21.11
* Plus de dictionnaires ont été ajoutés;
* La procédure de recherche a été modifiée afin qu'elle ne soit pas en respect de la casse;
* La présentation des résultats a été modifiée, ce qui vous permet maintenant de choisir une nouvelle recherche, copier le résultat ou sortir;
L'extension n'est fournie qu'avec des dictionnaires en anglais, portugais et les deux langues. Il est possible de télécharger le reste à partir d'un bouton de l'interface;
* Les dictionnaires sont hébergés à l'adresse www.tiflotecnia.net.

### Version 21.10
* Version initiale.

[1]: https://github.com/ruifontes/Dictionaries/releases/download/21.11/dictionaries-21.11.nvda-addon
