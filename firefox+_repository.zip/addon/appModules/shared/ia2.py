# ia2.py
# A part of An app module for NVDA
# Author: paulber19<paulber19@laposte.net>
# Copyright 2016, released under GPL.
#See the file COPYING for more details.

from logHandler import log
from IAccessibleHandler import accNavigate, accParent, splitIA2Attribs
from oleacc import NAVDIR_NEXT, NAVDIR_FIRSTCHILD, NAVDIR_LASTCHILD, NAVDIR_PREVIOUS, NAVDIR_UP, NAVDIR_LEFT

def get_ia2ID(obj):
		try:
			attributes = obj._get_IA2Attributes()
			if "id" in attributes.keys ():
				return attributes["id"]
		except:
			pass
		return None

def findObjectIndexByIA2Id(IAObj, id, toBottom = True, trace = False):
	try:
		(o, childID) = accNavigate(IAObj,0, NAVDIR_FIRSTCHILD)if toBottom else accNavigate(IAObj,0, NAVDIR_LASTCHILD)
		index = 0 if toBottom else IAObj.accChildCount -1
	except:
		log.warning("findObjectIndexByIA2ID: %s has no child"%IAObj)
		return None
	while o:
		try:
			attributes = splitIA2Attribs(o.attributes)
			if "id" in attributes.keys() and attributes["id"] == id:
				if trace:
					print("ia2 name: %s, id: %s" %(o.accName(0)),attributes["id"])
				return index
			else:
				if trace:
					print("ia2 name: %s, id: none" %o.accName(0))
		except:
			pass
		#(o, childID) = accNavigate(o,0, NAVDIR_NEXT)if toBottom else accNavigate(o,0, NAVDIR_PREVIOUS)
		try:
			(o, childID) = accNavigate(o,0, NAVDIR_NEXT)if toBottom else accNavigate(o,0, NAVDIR_PREVIOUS)
			index = index+1 if toBottom else index-1
			
		except:
			o = None
			
	return None

def findObjectByIA2IdEx(obj, id, toBottom = True, trace = False):
	if obj.childCount == 0:
		log.warning ("findObjectByIA2IdEx: %s has no childs"%obj)
		return None
	index = findObjectIndexByIA2Id(obj.IAccessibleObject, id, toBottom, trace)
	if index >=0:
		o = obj.getChild(index)
		return o
	return None
