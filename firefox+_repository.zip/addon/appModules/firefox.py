# Mozilla Apps Enhancements add-on for NVDA
#This file is covered by the GNU General Public License.
#See the file COPYING.txt for more details.
#~ #Copyright (C) 2017-2019 Javi Dominguez <fjavids@gmail.com>

from .py3compatibility import *
from logHandler import log
import addonHandler
import appModuleHandler
try:
	from nvdaBuiltin.appModules.firefox import AppModule
except ModuleNotFoundError:
	from appModuleHandler import AppModule
try:
	from NVDAObjects.IAccessible.mozilla import Dialog, IAccessible
except ImportError:
	from NVDAObjects.IAccessible import Dialog, IAccessible
import scriptHandler
import globalCommands
import controlTypes
import api
import ui
import winUser
import speech
import gui
import wx
import datetime
from threading import Timer
if py3flag:
	from urllib.parse  import urlparse
else:
	from urlparse import urlparse
import re
from . import shared
from . shared import ia2
from  . shared.ia2 import * 
from NVDAObjects import NVDAObject
from NVDAObjects.IAccessible import IAccessible
from oleacc import *
#
from tones  import beep
from gui.settingsDialogs import SettingsDialog
from keyboardHandler import KeyboardInputGesture
import config
import os
import appModuleHandler
from NVDAObjects.IAccessible import IAccessible
from NVDAObjects import NVDAObject
addonHandler.initTranslation()

def getIA2Attribute (obj,attribute_value=False,attribute_name ="id"):
	r= hasattr (obj,"IA2Attributes") and attribute_name in obj.IA2Attributes.keys ()
	if not r :return False
	r =obj.IA2Attributes[attribute_name]
	return r if not attribute_value  else r ==attribute_value

class TabsToolBar(object):  #Paul
	def __init__(self):
		self.oTabs= None
		try :
			oForeground = api.getForegroundObject()
			oForeground.ia2ID=get_ia2ID(oForeground)
			if (oForeground.IA2Attributes["tag"] != "body" and  (oForeground.ia2ID and oForeground.ia2ID!="main-window")):
				beep(1000,66)
				print ("pas dans fen principale")
				return
			oTabsToolbar = findObjectByIA2IdEx(oForeground, "TabsToolbar")
			if oTabsToolbar is None:
				return
		except :
			return  
		self.oTabs = oTabsToolbar.firstChild
		self.oTabsToolbar = oTabsToolbar
		
	def setFocus(self):
		self.getSelectedTab().IAccessibleObject.accSelect(1,0)

	def getSelectedTab(self):
		index = self.getSelectedTabIndex()
		return self.oTabs.getChild(index)
	
	def getSelectedTabIndex(self):
		i=0
		(o, id)  = accNavigate(self.oTabs.IAccessibleObject ,0,NAVDIR_FIRSTCHILD)
		while o:
			if o.accState(0) & STATE_SYSTEM_SELECTED:
				return i
			try:
				(o, id) = accNavigate(o,0,NAVDIR_NEXT)
				i= i+1
			except:
				o= None
		return None
	
	def getTabPosition(self):
		if self.oTabs is None:
			return ""
		count = self.oTabs.childCount -1
		if count>1:
			index = self.getSelectedTabIndex()
			return _("Tab {index} of {count}").format(index = index+1, count = count)    
		return ""
	
	def switchTo (self, oTab, speechMode):
		api.processPendingEvents()
		speech.cancelSpeech()
		speech.speechMode = speechMode
		oTab.doAction()


class Document(NVDAObject):   #Paul
	def _get_name(self):
		name=  super(Document, self)._get_name()
		if name is not None:
			name = "%s %s" %(name, TabsToolBar().getTabPosition())
		return name
	
class Tab(NVDAObject):  #Paul
	def initOverlayClass(self):
		self.bindGesture("kb:enter", "enter")
		
	def script_enter(self, gesture):
			KeyboardInputGesture.fromName("f6").send()
	
	__gestures ={
		"kb:enter": "enter",
		}
		
class toolsBarDialog(wx.Dialog):   # JD
	def __init__(self, parent):
		super(toolsBarDialog, self).__init__(parent, title="")
		mainSizer = wx.BoxSizer(wx.VERTICAL)
		self.listBox = wx.ListBox(self, wx.NewId(), style=wx.LB_SINGLE, size=(450, 300))  ##350, 200
		mainSizer.Add(self.listBox)
		self.Bind(wx.EVT_LISTBOX, self.onListBox, self.listBox)
		buttonsSizer = wx.BoxSizer(wx.HORIZONTAL)
		goButtonID = wx.NewId()
		#TRANSLATORS: go button in toolbar buttons dialog
		self.goButton = wx.Button(self, goButtonID, _("&Go"))
		buttonsSizer.Add(self.goButton)
		self.Bind( wx.EVT_BUTTON, self.onGoButton, id=goButtonID)
		optionsButtonID = wx.NewId()
		#TRANSLATORS: options button in toolbar buttons dialog
		self.optionsButton = wx.Button(self, optionsButtonID, _("&Options"))
		buttonsSizer.Add(self.optionsButton)
		self.Bind( wx.EVT_BUTTON, self.onOptionsButton, id=optionsButtonID)
		#TRANSLATORS: close button in toolbar buttons dialog
		cancelButton = wx.Button(self, wx.ID_CANCEL, _("Close"))
		buttonsSizer.Add(cancelButton)
		mainSizer.Add(buttonsSizer)
		mainSizer.Fit(self)
		self.SetSizer(mainSizer)
		self.goButton.SetDefault()

	def update(self, items, title):
		self.items = items
		self.SetTitle(title)
		self.listBox.SetItems([item.name for item in self.items])
		try:
			selected = [controlTypes.STATE_SELECTED in item.states for item in self.items].index(True)
		except ValueError:
			selected = 0
		self.listBox.Select(selected)
		self.listBox.SetFocus()

	def getObjectFromList(self):
		index = self.listBox.GetSelections()
		if index is not None:
			obj = self.items[index[0]]
			return(obj)

	def onListBox(self, event):
		if self.getObjectFromList().role == controlTypes.ROLE_BUTTON:
			self.optionsButton.Enabled = False
		else:
			self.optionsButton.Enabled = True

	def onGoButton(self, event):
		self.Hide()
		if self.moveMouseToObj():
			winUser.mouse_event(winUser.MOUSEEVENTF_LEFTDOWN,0,0,None,None)
			winUser.mouse_event(winUser.MOUSEEVENTF_LEFTUP,0,0,None,None)

	def onOptionsButton(self, event):
		self.Hide()
		if self.moveMouseToObj():
			winUser.mouse_event(winUser.MOUSEEVENTF_RIGHTDOWN,0,0,None,None)
			winUser.mouse_event(winUser.MOUSEEVENTF_RIGHTUP,0,0,None,None)

	def moveMouseToObj(self):
		obj = self.getObjectFromList()
		if obj:
			obj.scrollIntoView()
			api.moveMouseToNVDAObject(obj)
			api.setMouseObject(obj)
			return True
		return False  		

class AppModule(appModuleHandler.AppModule):

	tbDialog = None

	#TRANSLATORS: category for Firefox input gestures
	scriptCategory = _("Firefox")
	
	def chooseNVDAObjectOverlayClasses(self, obj, clsList):
		obj.ia2ID=get_ia2ID(obj)
		if (obj.ia2ID and  obj.ia2ID=="main-window") or getIA2Attribute (obj,False,"tag")=="body" or obj.role == controlTypes.ROLE_DOCUMENT:
			clsList.insert(0, Document) 
		# check if focus is a tab  in tabsToolbar.
		if obj.role == controlTypes.ROLE_TAB:
			oParent = obj.parent
			if (oParent.role == controlTypes.ROLE_TABCONTROL and oParent.ia2ID == "tabbrowser-tabs"):
				clsList.insert(0, Tab)		
	
	def script_goToTabsToolbar(self, gesture):  
		TabsToolBar().setFocus()
	script_goToTabsToolbar.__doc__ = _("Move the focus to tabs toolbar")
	script_goToTabsToolbar.category = _("Firefox")  
	
	def script_goToLibButton(self, gesture):  # control+shift+L bibliotheque
		if not self.inMainWindow() : return ui.message(_("Not available here"))
		try :
			path = (("id", "nav-bar"), ("id", "library-button"))
			oLibButton = shared.searchObject(path)
			if oLibButton is None:
				return
			oLibButton.doAction()
			wx.CallLater(300,ui.message ,_("Library button, type downArrow") )
		except :
			return  
	script_goToTabsToolbar.__doc__ = _("Move the focus to tabs toolbar")
	script_goToTabsToolbar.category = _("Firefox")  	
	
	def script_tabMovement(self, gesture):
		gesture.send()
		time.sleep(0.3)
		obj=api.getForegroundObject()
		basestring = str
		title=obj.name
		if not isinstance(title,basestring) or not title or title.isspace():
			title=obj.appModule.appName  if obj.appModule else None
			if not isinstance(title,basestring) or not title or title.isspace():
				return
		ui.message(title) 

	def event_alert(self, obj, nextHandler):
		try:
			if obj.IA2Attributes["id"] == "customizationui-widget-panel":
				# Firefox add-on panel
				speech.cancelSpeech()
				api.setFocusObject(obj.simpleFirstChild)
				nextHandler()
				return
		except (KeyError, AttributeError):
			pass
		if re.match(".*notification.*|.*alert.*", ";".join(obj.IA2Attributes.values()).lower()):
			try:
				isPopup = obj.IA2Attributes["id"] == "notification-popup"
			except (KeyError, AttributeError):
				isPopup = False
			if self.inMainWindow() and isPopup:
				if shared.focusAlertPopup(obj):
					Timer(0.75, nextHandler)
					return
			alertText = shared.getAlertText(obj)
			# Appends the domain of the page where it was when the alert originated.
			path = (("id", "nav-bar"), ("id", "urlbar"), ("class", "urlbar-input textbox-input",))
			url = shared.searchObject(path)
			if url and url.value:
				url = url.value if "://" in url.value else "None://"+url.value
				domain = urlparse(url).hostname if url else ""
				if domain and domain not in alertText: alertText = "%s\n\n%s" % (alertText, domain)
			shared.notificationsDialog.registerFirefoxNotification((datetime.datetime.now(), alertText))
		nextHandler()

	def script_status(self, gesture):
		if not self.inMainWindow():
			#TRANSLATORS: message spoken by NVDA when the focus is not in the main Firefox window
			ui.message(_("Not available here"))
			return
		group = shared.searchAmongTheChildren(("tag", "tabpanels"), api.getForegroundObject())
		if group:
			for propertyPage in filter(lambda o: o.role == controlTypes.ROLE_PROPERTYPAGE, group.children):
				try:
					obj = filter(lambda o: o.role == controlTypes.ROLE_STATUSBAR, propertyPage.children)[0]
					break
				except IndexError:
					pass
			try:
				ui.message(obj.name)
			except NameError:
				#TRANSLATORS: message spoken when there is no status bar in Firefox
				ui.message (_("Status bar not found"))
			else:
				if scriptHandler.getLastScriptRepeatCount() == 1:
					if api.copyToClip(obj.name):
						#TRANSLATORS: message spoken when an item hast just been copied to the clipboard
						ui.message(_("Copied to clipboard"))
			return
		#TRANSLATORS: Firefox status bar not found
		ui.message (_("Status bar not found"))
	#TRANSLATORS: message shown in Input gestures dialog for this script
	script_status.__doc__ = _("Reads the status bar. If pressed twice quickly, copies it to clipboard.")

	def script_url(self, gesture):
		if not self.inMainWindow():
			#TRANSLATORS: message spoken by NVDA when the focus is not in the main Firefox window
			ui.message(_("Not available here"))
			return
		ffVersion = int(self.productVersion.split(".")[0])
		if ffVersion < 70:
			path = (("id", "nav-bar"), ("id", "urlbar"), ("id", "identity-box",))
		elif ffVersion < 76:
			path = (("id", "nav-bar"), ("id", "identity-box"), ("id", "identity-icon"))
		else:
			path = (("id", "nav-bar"), ("id", "identity-box"))
		secInfoButton = shared.searchObject(path)
		if secInfoButton:
			securInfo = secInfoButton.description # This has changed in FF 57. Keeping this line for compatibility with earlier versions.
			try: # This one is for FF 57 and later.
				try: # FF 57 to 69
					securInfo = secInfoButton.firstChild.next.name if secInfoButton.firstChild.next.IA2Attributes["id"] == "connection-icon" else ""
					if securInfo:
						owner = " ".join([o.name for o in filter(lambda o: o.role == controlTypes.ROLE_STATICTEXT, secInfoButton.recursiveDescendants)])
						securInfo = "%s, %s" % (owner, securInfo) if owner else securInfo
				except AttributeError: # FF 70 and above 
					securInfo = secInfoButton.name
			except:
				pass
			#TRANSLATORS: this connection is using http, not https
			securInfo  = _("Insecure connection") if not securInfo   else securInfo  
			if ffVersion < 76:
				url = secInfoButton.next.value if ffVersion < 70 else secInfoButton.parent.next.firstChild.value
				ui.message("%s (%s)" % (url, securInfo))
			else:
				url = secInfoButton.next.firstChild.value
				ui.message(url)
			if scriptHandler.getLastScriptRepeatCount() == 1:
				if api.copyToClip(url):
					#TRANSLATORS: message spoken when an item hast just been copied to the clipboard
					ui.message(_("Copied to clipboard"))
			return
		#TRANSLATORS: message spoken when addres bar could not be found
		ui.message (_("Address not found"))
	#TRANSLATORS: description shown in input gestures dialog for this script
	script_url.__doc__ = _("Reads the page address. If pressed twice quickly, copies it to clipboard.")

	def script_toolsBar(self, gesture):
		if scriptHandler.getLastScriptRepeatCount() == 0:
			self.showToolbarDialog(False)
		elif scriptHandler.getLastScriptRepeatCount() == 1:
			self.showToolbarDialog(True)
	#TRANSLATORS: documentation shown in the input gestures dialog for this script
	script_toolsBar.__doc__ = _("Shows a list of opened tabs. If pressed twice quickly, shows buttons of tool bar.")

	def script_toolsBar2(self, gesture):
		self.showToolbarDialog(True)
	#TRANSLATORS: documentation shown in the input gestures dialog for this script
	script_toolsBar2.__doc__ = _("Shows buttons of tool bar.")

	def showToolbarDialog(self, twice):
		if not self.inMainWindow() and api.getForegroundObject().appModule.productName != "NVDA":
			#TRANSLATORS: message spoken by NVDA when the focus is not in the main Firefox window
			ui.message(_("Not available here"))
			return
		if not self.tbDialog:
			self.tbDialog = toolsBarDialog(gui.mainFrame)
		if twice:
			items, title = self.getButtonsDialog()
		else:
			items, title = self.getTabsDialog()
		if items:
			self.tbDialog.update(items, title)
			if not self.tbDialog.IsShown():
				gui.mainFrame.prePopup()
				self.tbDialog.CenterOnScreen()
				self.tbDialog.Show(True)
				gui.mainFrame.postPopup()
			return
		#TRANSLATORS: message spoken when Firefox toolbar is not found
		ui.message (_("Tool bar not found"))

	def script_notifications(self, gesture):
		obj = api.getForegroundObject().simpleFirstChild
		if obj.role == controlTypes.ROLE_ALERT:
			if api.getFocusObject().parent == obj: # Already focused
				speech.speakObject(obj)
				speech.speakObject(api.getFocusObject())
				return
			if shared.focusAlertPopup(obj):
				speech.speakObject(api.getFocusObject())
				return
		if not shared.notificationsDialog.isEmpty():
			if scriptHandler.getLastScriptRepeatCount() == 1:
				# Gesture repeated twice shows the complete history in a dialog box.
				shared.notificationsDialog.firefoxPage()
				return
			else:
				# Gesture once says the last notification
				if shared.notificationsDialog.history["Firefox"]:
					timestamp, message = shared.notificationsDialog.history["Firefox"][0]
					ui.message("%s, %s" % (shared.elapsedFromTimestamp(timestamp), message))
					return
		# There is no notification in Firefox or Thunderbird
		ui.message(_("There is no notification"))
	#TRANSLATORS: documentation shown in the input gestures dialog for this script
	script_notifications.__doc__ = _("Reads the last notification and it takes the system focus to it if it is possible. By pressing two times quickly shows the history of notifications.")

	def script_focusDocument(self, gesture):
		if not self.inMainWindow():
			#TRANSLATORS: message spoken by NVDA when the focus is not in the main Firefox window
			ui.message(_("Not available here"))
			return
		group = shared.searchAmongTheChildren(("tag", "tabpanels"), api.getForegroundObject())
		if group:
			for propertyPage in filter(lambda o: o.role == controlTypes.ROLE_PROPERTYPAGE, group.children):
				try:
					doc = filter(lambda o: o.role == controlTypes.ROLE_INTERNALFRAME and controlTypes.STATE_FOCUSABLE in o.states, propertyPage.children)[0].children[0]
					break
				except IndexError:
					pass
			try:
				api.setFocusObject(doc)
				try:
					doc.treeInterceptor.passThrough = False
				except AttributeError:
					pass
				ui.message("%s %s" % (controlTypes.roleLabels[doc.role], doc.name))
			except NameError:
				pass
	#TRANSLATORS: documentation shown in the input gestures dialog for this script
	script_focusDocument.__doc__ = _("Brings the focus to the document")

	def getTabsDialog(self):
		tabs = ""
		fg = api.getForegroundObject()
		for toolBar in filter(lambda o: o.role == controlTypes.ROLE_TOOLBAR, fg.children):
			try:
				tabControl = filter(lambda o: o.role == controlTypes.ROLE_TABCONTROL, toolBar.children)[0]
			except IndexError:
				pass
			else:
				tabs = filter(lambda o: o.role == controlTypes.ROLE_TAB, tabControl.children)
		#TRANSLATORS: opened tabs in tabs dialog
		return tabs, "%d %s" % (len(tabs), _("Opened tabs"))

	def getButtonsDialog(self):
		fg = api.getForegroundObject()
		buttons = []
		for toolBar in filter(lambda o: o.role == controlTypes.ROLE_TOOLBAR and "id" in o.IA2Attributes and o.IA2Attributes["id"] != "TabsToolbar", fg.children):
			buttons = buttons + filter(lambda o: o.role == controlTypes.ROLE_BUTTON and controlTypes.STATE_OFFSCREEN not in o.states, toolBar.children)
		#TRANSLATORS: Toolbar buttons dialog
		return buttons, _("Tool Bar Buttons")

	def inMainWindow(self):
		fg = api.getForegroundObject()
		try:
			if fg.IA2Attributes["id"] == "main-window":
				return True
		except (AttributeError, KeyError):
			pass
		# As of Firefox 72, the IA2Attributes["id"]:"main-window" is no longer used
		try:
			if fg.IA2Attributes["tag"] == "body":
				return True
		except (AttributeError, KeyError):
			pass

	__gestures = {
		"kb:control+=":"goToTabsToolbar", 
		# "kb:control+shift+B":"toolsBar2",  
		"kb:control+shift+L":"goToLibButton",
		"kb:control+shift+pageUp": "tabMovement",
		"kb:control+shift+pageDown": "tabMovement",
		#
		"kb(desktop):NVDA+End": "status",
		"kb(laptop):NVDA+Shift+End": "status",
		"kb:NVDA+F8": "toolsBar",
		"kb(desktop):NVDA+shift+A": "url",
		"kb(laptop):NVDA+Control+A": "url",
		"kb:NVDA+Control+N": "notifications",
		"kb:NVDA+F6": "focusDocument"
	}


