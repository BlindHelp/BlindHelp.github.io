# Extension NVDA pour Firefox et Waterfox.
 
 Version actuelle : 2.0, du 02.11.2020.

Cette extension rassemble l'extension Firefox 1.2 de PaulBert, qui n'est plus maintenue, et la partie "Firefox" de l'extension "Mozilla" version 1.12, de Javi Dominguez.

Elle apporte des commandes pour facilité l'utilisation de Firefox et de Waterfox, et une meilleure vocalisation dans l'utilisation des onglets (en particulier le rang et le total, par exemple 2 sur 4).

Elle est utilisable avec NVDA 2019.3 et suivants, Firefox version 68 et suivants, Waterfox 2020.10, Windows 7 à 10.


### Les commandes apportées par l'extension de Javi Dominguez.
* NVDA+A (desktop) ou NVDA+Contrôle+A (laptop) : lire l’adresse de la page. Une double frappe la copie dans le presse-papiers. Cette commande fait double emploi avec la commande apportée par l'extension "Extension des commandes de base de NVDA", mais elles donnent le même résultat, et coexistent si l'extension "Extension des commandes de base de NVDA" est installée.
* NVDA+Fin (desktop) ou NVDA+Majuscule+Fin (laptop) : lire la barre d’état. Une double frappe la copie dans le presse-papiers.
* NVDA+F8 : afficher une liste des onglets ouverts dans une boite de dialogue. Une double frappe fait afficher une boite de dialogue avec la liste des boutons dans la barre de navigation, et dans la barre personnelle.
* NVDA+Contrôle+N : lire la dernière notification et y amène le focus si possible. Une double frappe fait afficher l’historique des notifications.
* NVDA+F6 : déplacer le focus dans le contenu du document.

### Les autres commandes actuellement disponibles.
* Ctrl+égal : sélectionner l'onglet actif dans la barre des onglets.
* Ctrl+Maj+page suivante / précédente : cette commande de Mozilla est vocalisée.
* F6 : déplacement entre la barre d'adresses et le contenu du document.
* Ctrl+Maj+L : activer le bouton "Bibliothèque". Ceci fait afficher un menu contextuel, où vous entrerez par Flèche bas. Ce bouton n'existe pas dans Waterfox.

Indications.

* Waterfox est une version dérivée de Firefox, écrite directement en 64 bits, donc censée être plus rapide. Ell présente également l'avantage d'accepter des extensions qui ne sont plus utiilisables sur Firefox actuel, telle que FireFTP.
* Avant d'installer cette extension, assurez-vous que les extensions d'origine ne sont pas installées.
* Vous trouverez une série de pages sur l'utilisation de Firefox avec NVDA et cette extension, un lien de téléchargement de l'extension, à partir de cette page :

[http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/firefox/index.htm](http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/firefox/index.htm)