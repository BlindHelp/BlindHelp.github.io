# Extension NVDA pour Firefox et Waterfox.
 
 Version actuelle : 2.0, du 06.11.2020.

Cette extension compile l'extension Firefox 1.2 de PaulBert, qui n'est plus maintenue, et la partie "Firefox" de l'extension "Mozilla" version 1.12, de Javi Dominguez.

Elle apporte des commandes pour faciliter l'utilisation de Firefox et de Waterfox, et une meilleure vocalisation dans l'utilisation des onglets (en particulier le rang et le total, par exemple 2 sur 4).

Elle est utilisable avec NVDA 2019.1 et suivants, Firefox versions 68 et suivantes, Waterfox 2020.x, Windows 7 à 10.


### Les commandes apportées par l'extension de Javi Dominguez.
* NVDA+Shift+A (desktop) ou NVDA+Control+A (laptop) : lire l’adresse de la page. Une double frappe la copie dans le presse-papiers. 
Cette commande existe dans l'extension "Extension des commandes de base de NVDA", avec des raccourcis différents : NVDA+A (desktop) ou NVDA+Shift+A (laptop).
* NVDA+Fin (desktop) ou NVDA+Majuscule+Fin (laptop) : lire la barre d’état. Une double frappe la copie dans le presse-papiers.
* NVDA+F8 : afficher une liste des onglets ouverts dans une boite de dialogue. Une double frappe fait afficher une boite de dialogue avec la liste des boutons dans la barre de navigation, et dans la barre personnelle.
* NVDA+Control+N : lire la dernière notification et y amène le focus si possible. Une double frappe fait afficher l’historique des notifications (seulement avec Firefox).
* NVDA+F6 : déplacer le focus dans le contenu du document.

### Les autres commandes actuellement disponibles.
* Ctrl+égal : sélectionner l'onglet actif dans la barre des onglets.
* Ctrl+Maj+page suivante / précédente : vocaliser cette commande de Mozilla.
* F6 : déplacement entre la barre d'adresses et le contenu du document.
* Ctrl+Maj+L : activer le bouton "Bibliothèque". Ceci fait afficher un menu contextuel, où vous entrerez par Flèche bas. Ce bouton n'existe pas dans Waterfox.

Indications.

* Waterfox est une version dérivée de Firefox, écrite directement en 64 bits, donc censée être plus rapide. Ell présente également l'avantage d'accepter des extensions qui ne sont plus utiilisables sur Firefox actuel, telle que FireFTP.
* Avant d'installer cette extension, assurez-vous que les extensions d'origine ne sont pas installées.
* Vous trouverez une série de pages sur l'utilisation de Firefox avec NVDA et cette extension, un lien de téléchargement de l'extension, à partir de cette page :

[http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/firefox/index.htm](http://angouleme.avh.asso.fr/fichesinfo/fiches_nvda/firefox/index.htm)