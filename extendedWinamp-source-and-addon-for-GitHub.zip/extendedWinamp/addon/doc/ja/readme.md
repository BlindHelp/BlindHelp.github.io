# extendedWinamp #

* 作者: Hrvoje Katic and NVDA-addon-team
* Download: [version 1.2][1]

この拡張モジュールは、NVDA標準のWinampにいくつかの機能を追加しています。

* S トグル シャッフルのオン・オフ
* R トグル リピートのオン・オフ
* F5 再生ミュート
* F6 再生ボリューム 25パーセント
* F7 再生ボリューム 50パーセント
* F8 再生ボリューム 100パーセント
* Shift+左矢印 パン左
* Shift+右矢印 パン右
* Shift+上矢印 パン中央
* Ctrl+Shift+T トラックの合計時間を読み上げ
* Ctrl+Shift+E トラックの経過時間を読み上げ
* Ctrl+Shift+R トラックの残り時間を読み上げ
* Shift+R トラックの最後をレビュー(初期設定では6秒)
* Ctrl+R 「トラックの最後をレビュー」の長さ(秒)を設定
* Shift+J 代替ジャンプの長さ(秒)を設定
* Ctrl+右矢印 早送り代替ジャンプ(初期設定では6秒)
* Ctrl+左矢印 巻き戻し代替ジャンプ(初期設定では6秒)

## 1.1 での変更点 ##

* 新しい言語：アラゴン、フランス語、フィンランド語、アラビア語、オランダ語、ドイツ語、ガリシア語、ロシア語、ハンガリー語、イタリア語、日本語、韓国語、ネパール語、ポルトガル語（ブラジル）、スロベニア語、スロバキア語、スペイン語、タミル語、トルコ語。

## Changes for 1.0 ##

* Initial Release

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon

