# extendedWinamp #

* Auteurs: Hrvoje Katic en het NVDA-addon-team
* Download: [versie 1.2][1]

Deze appmodule breidt de met NVDA meegeleverde Winamp appmodule uit met
extra functionaliteit. 

* s Schakel shuffle aan/uit
* r Schakel herhalen aan/uit
* F5 Afspelen dempen
* F6 Afspeelvolume op 25% instellen
* F7 Afspeelvolume op 50% instellen
* F8 Afspeelvolume op 100% instellen
* Shift+pijl naar links Balans naar links
* Shift+pijl naar rechts Balans naar rechts
* Shift+pijl omhoog Balans in het midden
* Ctrl+Shift+T Spreekt totale lengte van het nummer
* Ctrl+Shift+D Spreekt afgespeelde tijd van het nummer
* Ctrl+Shift+R Spreekt resterende tijd van het nummer
* Shift+R Beluister einde van het nummer (standaard laatste 6 seconden)
* Ctrl+R Stel de tijd voor het beluisteren van het eind van het nummer in
* Shift+J Stel een aangepaste tijd in voor het springen
* Ctrl+Pijl rechts Spring de aangepaste tijd naar voren
* Ctrl+Pijl links Spring de aangepaste tijd naar achteren

## Veranderingen voor 1.1 ##

* Nieuwe vertalingen: Aragonees, Arabisch, Nederlands, Duits, Fins, Frans,
  Gallisch, Hongaars, Italiaans, Japans, Koreaans, Nepali, Portugees
  (Brazilië), Russisch, Slowaaks, Sloveens, Spaans, Tamil, Turks.

## Veranderingen voor 1.0 ##

* Eerste versie

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
