# extendedWinamp #

* Autori: Hrvoje Katic a tím NVDA
* Stiahnuť: [verzia 1.2][1]

Tento doplnok rozširuje aplikačný modul Winampu o ďalšie funkcie.

* s: vypne alebo zapne náhodný výber
* r: vypne alebo zapne opakovanie
* F5: stlmiť prehrávanie
* F6: nastaví hlasitosť prehrávania na 25 %
* F7: Nastaví hlasitosť prehrávania na 50 %
* F8: Nastaví maximálnu hlasitosť prehrávania
* Shift+ľavá šípka: vyváženie doľava
* Shift+pravá šípka: vyváženie doprava
* Shift+šípka hore: vyváženie na stred
* Ctrl+Shift+t: prečíta celkovú dĺžku skladby
* Ctrl+Shift+e: prečíta uplynutý čas skladby
* Ctrl+Shift+r: prečíta zostávajúci čas prehrávania skladby
* Shift+r: Náhľad konca skladby "predvolene posledných 6 sekúnd"
* Ctrl+r: Nastaviť čas náhľadu "v sekundách" použije sa pri použití funkcie
  náhľad konca skladby
* Shift+j: Nastaviť čas alternatívneho skoku "v sekundách"
* Ctr+pravá šípka: alternatívny skok dopredu "predvolene 6 sekúnd"
* Ctrl+ľavá šípka: Alternatívny skok dozadu "predvolene 6 sekúnd "

## Zmeny pre verziu 1.1 ##

* Nové jazyky: Aragónčina, Arabčina, Holandčina, Nemčina, Fínčina,
  Francúzsština, Galijcíčina, Maďarčina, Taliančina, japončina, Kórejčina,
  nepálčina, Brazílska portugálčina, Ruština, Slovenčina, Slovinčina,
  Španielčina, Tamilčina, Turečtina.

## Zmeny pre 1.0 ##

* prvé vydanie

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
