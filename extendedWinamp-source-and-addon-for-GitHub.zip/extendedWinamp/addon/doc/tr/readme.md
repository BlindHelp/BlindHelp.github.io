# extendedWinamp #

* Geliştiriciler: Hrvoje Katic ve NVDA-eklenti-ekibi
* İndir: [version 1.2][1]

Bu geliştirilmiş uygulama modülü NVDA'nın orijinal winamp modülüne extra
işlevler eklemektedir.

* s karışık çalmayı açıp kapatır
* r tekrar çalmayı açıp kapatır
* F5 sesini tamamen kısar
* F6 sesi %25 seviyesine getirir
* F7 sesi %50 seviyesine getirir
* F8 sesi %100 seviyesine getirir
* Shift+sol ok sesi sola kaydırır 
* Shift+Sağ ok sesi sağa kaydırır
* Shift+Yukarı ok sesi ortalar
* Control+Shift+t toplam süreyi söyler
* Control+Shift+e geçen süreyi söyler
* Control+Shift+r kalan süreyi söyler
* Shift+r parça sonunu çalar "varsayılan süre 6 saniyedir"
* Control+r Parça sonu için süre belirlenir
* Shift+j alternatif ileri-geri alma süresi belirlenir
* Control+Sağ ok alternatif ileri alma "varsayılan süre 6 saniye "
* Control+Sol ok alternatif  geri alma "varsayılan süre 6 saniye"

## 1.1 için değişiklikler ##

* Yeni diller: Aragonese, Arabic, Dutch, German, Finnish, French, Galician,
  Hungarian, Italian, Japanese, Korean, Nepali, Portuguese (Brazil),
  Russian, Slovak, Slovenian, Spanish, Tamil, Turkish.

## 1.0 için değişiklikler ##

* İlk sürüm

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
