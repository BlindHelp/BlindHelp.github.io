# Rozszerzone funkcje NVDA w Winamp /extendedWinamp #

* Autorzy: Hrvoje Katic i NVDA-addon-team
* Pobierz: [wersja 1.2][1]

Ten dodatek rozszerza domyślny modół NVDA dla winampa, dodając nowe funkcje.

* s Przełącza tryb losowania
* r przełącza powtarzanie utworu
* f5 wycisza odtwarzanie
* f6 ustawia głośność odtwarzania na 25%
* f7 ustawia głośność odtwarzania na 50%
* f8 ustawia głośność odtwarzania na 100%
* shift strzałka w lewo -  balans w lewo
* shift strzałka w prawo - balans w prawo.
* shift strzałka w górę - ustawia balans na środek
* ctrl+shift+t odczytuje długość utworu.
* ctrl+shift+s - podaje miniony czas od początku utworu
* ctrl+shift+r - podaje pozostały czas
* shift+r podgląd końca utworu (domyślnie 6 sekund)
* ctrl+r ustawia czas podglądu końca utworu
* shift+j ustawia czas przeskoku w sekundach
* ctrl+strzałka w prawo - przeskakuje w przód (domyślnie 6 sekund)
* ctrl+lewo przeskakuje w tył (domyślnie 6 sekund)

## zmiany dla wersji 1.1 ##

* Nowe języki: Aragoński, Arabski, Duński, Niemiecki, Fiński, Francuski,
  Galicyjski, Węgierski, Włoski, Japoński, Koreański, Nepali, Portugalski
  (brazylijski), Rosyjski, Słowacki, Słoweński, Hiszpański, Tamil, Turecki.

## zmiany dla wersji 1.0 ##

* wstępne wydanie.

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
