# extendedWinamp #

* Autores: Hrvoje Katic e o eqipo de complementos do NVDA
* Descarga: [versión 1.2][1]

Este complemento extendido extende o appModule orixinal do Winamp que se
atopa en NVDA con algunha funcionalidade extra.

* s activa ou desactiva modo aleatorio
* r activa ou desactiva repetición
* F5 silenza a reproducción
* F6 pon o volume de reproducción a 25%
* F7 pon o volume de reproducción a 50%
* F8 pon o volume de reproducción a 100%
* Shift+FlechaExquerda valance á Esquerda
* Shift+FlechaDereita valance á dereita
* Shift+FlechaArriba valance ó centro
* Control+Shift+t di a lonxitude total da pista
* Control+Shift+e di o tempo transcorrido da pista
* Control+Shift+r di o tempo restante da pista
* Shift+r Revisa o final da pista "últimos 6 segundos por omisión"
* Control+r configura o tempo en revisión"en segundos" para utilizar con
  Revisar final da Pista command
* Shift+j configura o tempo de salto alternativo "en segundos"
* Control+FlechaDereita Salto Alternativo Adiante "6 segundos por omisión"
* Control+FlechaEsquerda Salto Alternativo Atrás "6 segundos por omisión"

## Cambios para 1.1 ##

* Novas linguas: Aragonés, Árabe, Holandés, Alemán, Finlandés, Francés,
  Galego, Húngaro, Italiano, Xaponés, Coreano, Nepalí, Portugués (Brasil),
  Ruso, Eslovaco, Esloveno, Español, Tamil, Turco.

## Cambios para 1.0 ##

* Versión Inicial

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
