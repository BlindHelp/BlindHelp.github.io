# Winamp kiegészítő #

* Fejlesztők: Hrvoje Katic, és az NVDA kiegészítői csoport
* Letöltés: [1.2-es verzió][1]

Ez a szkript új funkciókkal bővíti ki az NVDA-ban található Winamp
szkriptet.

* s be/kikapcsolja a véletlen lejátszást
* r be/kikapcsolja az ismétlést
* F5 elnémítja a lejátszást
* F6 a lejátszás hangerejét 25%-ra állítja
* f7 a lejátszás hangerejét 50%-ra állítja
* f8 a lejátszás hangerejét 100%-ra állítja
* Shift+balra nyíl a balansz balra mozgatása
* Shift+jobbra nyíl a balansz jobbra mozgatása
* Shift+fel nyíl A balansz középre helyezése
* Control+Shift+t bemondja a szám teljes hosszát
* Control+Shift+e bemondja a számból már eltelt időt
* Control+Shift+r bemondja a számból még hátralévő időt
* Shift+r Belehallgatás a szám végébe "alapértelmezésben az utolsó 6
  másodpercbe"
* Control+r A szám végi lejátszás beállítása "másodpercben"
* Shift+j Szabályozható tekerés idejének beállítása
* Control+jobbra nyíl Szabályozható előretekerés "alapértelmezetten 6
  másodperccel"
* Control+balra nyíl Szabályozható visszatekerés "alapértelmezetten 6
  másodperccel"

## Az 1.1 verzió változásai ##

* Új nyelvek: Aragóniai, Arab, Holland, Német, Finn, Francia, Galíciai,
  Magyar, Olasz, Japán, Kóreai, Nepáli, Brazil Portugál, Orosz, Szlovák,
  Szlovén, Spanyol, Tamil, Török.

## Az 1.0 verzió változásai ##

* Első verzió

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
