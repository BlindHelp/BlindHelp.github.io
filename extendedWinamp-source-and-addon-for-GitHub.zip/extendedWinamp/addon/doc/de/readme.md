# extendedWinamp #
[[!meta title="ErweitertesWinamp"]]

* Autoren: Hrvoje Katic und das NVDA-Erweiterungs-Team
* Download: [version 1.2][1]

Dieses Anwendungsmodul erweitert das Winamp-Anwendungsmodul, welches mit
NVDA mitgeliefert wird, mit zusätzlichen Funktionen.

* s zufällige Widergabe ein-/ausschalten
* r Widerholung ein-/ausschalten
* F5 stumm schalten
* F6 Wiedergabelautstärke auf 25% einstellen
* F7 Wiedergabelautstärke auf 50% einstellen
* F8 Wiedergabelautstärke auf 100% einstellen
* Umschalt+Pfeiltaste nach links Panorama links
* Umschalt+Pfeiltaste nach rechts Panorama rechts
* Umschalt+Pfeiltaste nach oben Panorama zentriert
* Steuerung+Umschalt+t spricht die Gesamtlänge des Titels.
* Steuerung+Umschalt+e spricht die verstrichene Zeit des Titels aus
* Steuerung+Umschalt+r spricht die verbleibende Zeit des Titels
* Umschalt+r gibt die das Ende des Titels wieder "standardmäßig die letzten
  6 Sekunden"
* Steuerung+r legt die Zeit fest, die beim Wiedergeben des Titelendes
  benutzt werden soll.
* legt die Zeit für den alternativen Vor-/Rücklauf fest "in Sekunden"
* altenativer Vorlauf "standardmäßig 6 Sekunden"
* alternativer Rücklauf "standardmäßig 6 Sekunden"

## Änderungen bis 1.1 ##

* Neue Sprachen: Aragonesisch, Arabisch, niderländisch, deutsch, Finnisch,
  Französisch, Gälisch, ungarisch, Italienisch, Japanisch, Koreanisch,
  Nepalesisch, Portugisisch (Brazilianisch), Russisch, Slovakisch,
  Slovenisch, Spanisch, Tamil, Türkisch.

## Änderungen bis 1.0 ##

* Ehrstveröffentlichung

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
