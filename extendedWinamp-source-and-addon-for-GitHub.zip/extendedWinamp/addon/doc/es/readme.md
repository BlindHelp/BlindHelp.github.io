# extendedWinamp #

* Autores: Hrvoje Katic, Beqa Gozalishvili y el equipo de complementos de NVDA
* Descarga: [versión 1.2][1]

Este appModule extendido amplía el appModule  original para Winamp que se
encuentra en NVDA con cierta funcionalidad extra.

* s Activar o desactivar Aleatorio
* r activar o desactivar repetir
* F5 silenciar la reproducción
* F6 fijar el volumen de la reproducción a 25%
* F7 fijar el volumen de la reproducción a 50%
* F8 fijar el volumen de la reproducción a 100%
* Shift+FlechaIzquierda Valance a la Izquierda
* Shift+FlechaDerecha Valance a la Derecha
* Shift+FlechaArriba Valance al Centro
* Control+Shift+t verbaliza el total de la duración de la Pista
* Control+Shift+e verbaliza el Tiempo Transcurrido de la Pista
* Control+Shift+r verbaliza el Tiempo Restante de la Pista
* Shift+r Revisar el final de la pista "últimos 6 segundos por omisión"
* Control+r fija el tiempo de revisión "en segundos" para utilizar con la
  orden Revisar final de la Pista
* Shift+j Ajusta tiempo de salto alternativo "en segundos"
* Control+FlechaDerecha Salto Alternativo adelante "6 segundos por omisión"
* Control+FlechaIzquierda Salto Alternativo Atrás "6 segundos por omisión"

## Cambios para 1.2-dev ##

* Actualizado el complemento para trabajar en NVDA 2021 y superior.
* Nuevos idiomas: Croata, Polaco, Chino Simplificado.

## Cambios para 1.1 ##

* Nuevos idiomas: Alemán, árabe, Aragonés, Coreano, Eslovaco, Esloveno,
  Español, Finlandés, Francés, Gallego, Holandés, Húngaro, Italiano,
  Japonés, Nepalí, Portugués (Brasil), Ruso, Tamil, Turco.

## Cambios para 1.0 ##

* Versión Inicial

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
