# extendedWinamp #

* Auteurs: Hrvoje Katic, Beqa Gozalishvili et l'équipe des extensions NVDA
* Télécharger : [version 1.2][1]

Cette extension applicative enrichit le script de Winamp inclus dans NVDA avec des
fonctionnalités suplémentaires.

* s active ou désactive le mode alléatoire
* r active ou désactive le mode répétition
* F5 coupe le son
* F6 change le volume à 25%
* F7 change le volume à 50%
* F8 change le volume à 100%
* Maj+Flèche gauche son plus à gauche
* Maj+Flèche droite son plus à droite
* Maj+Flèche haute son au centre
* Control+Maj+t annonce la durée de la piste
* Control+Maj+e annonce le temps écoulé
* Control+Maj+r annonce le temps restant
* Maj+r écouter la fin de la piste (six dernières secondes par défaut)
* Control+r définir le temps de fin de piste (en secondes) à utiliser
  lorsque l'on appel la commande écouter la fin de la piste
* Maj+j définir le temps de saut alternatif (en secondes)
* Control+Flèche droite saut en avant alternatif (six secondes par défaut)
* Control+Flèche gauche saut en arrière alternatif (six secondes par défaut)

## Changements pour la version 1.2-dev ##

* Extension mis à jour pour travailler sur NVDA 2021 et supérieur.
* Nouvelles langues: Croate, Polonais, Chinois simplifié.

## Changements pour la version 1.1 ##

* Nouvelles langues: Aragonais, Arabe, Néherlandais, Allemand, Finnois,
  Français, Galicien, Hongrois, Italien, Japonais, Koréen, Népalais,
  Portuguais (Brésil), Russe, Slovak, Slovénien, Espagnol, Tamoul, Turque.

## Changements pour la version 1.0 ##

* Première version

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
