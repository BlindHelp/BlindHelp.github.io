# Laajennettu Winamp #

* Tekijät: Hrvoje Katic ja NVDA:n lisäosatiimi
* Lataa: [versio 1.2][1]

Tämä sovellusmoduuli laajentaa alkuperäistä NVDA:n Winamp-sovellusmoduulia
muutamilla lisätoiminnoilla.

* S: sekoitus päälle/pois
* R: uudelleentoisto päälle/pois
* F5: mykistä toisto
* F6: aseta toiston äänenvoimakkuudeksi 25 %
* F7: aseta toiston äänenvoimakkuudeksi 50 %
* F8: aseta toiston äänenvoimakkuudeksi 100 %
* Shift+vasen nuoli: panorointi vasemmalla
* Shift+oikea nuoli: panorointi oikealla
* Shift+ylänuoli: panorointi keskellä
* Control+Shift+T: Lukee kappaleen kokonaiskeston
* Control+Shift+E: Lukee kappaleen kuluneen ajan
* Control+Shift+R: Lukee kappaleen jäljellä olevan ajan
* Shift+R: Kuuntele kappaleen loppu (oletusarvoisesti viimeiset 6 sekuntia)
* Control+R: Aseta kuunteluaika (sekunteina) Kuuntele kappaleen loppu
  -komennolla käytettäväksi
* Shift+J: Aseta vaihtoehtoinen hyppyaika (sekunteina)
* Control+oikea nuoli: Vaihtoehtoinen hyppy eteenpäin (oletusarvoisesti 6
  sekuntia)
* Control+vasen nuoli: Vaihtoehtoinen hyppy taaksepäin (oletusarvoisesti 6
  sekuntia)

## Muutokset versiossa 1.1 ##

* Uusia kieliä: arabia, aragonia, brasilianportugali, espanja, galego,
  hollanti, italia, japani, korea, nepali, ranska, saksa, slovakki,
  slovenia, suomi, tamili, turkki, unkari, venäjä.

## Muutokset versiossa 1.0 ##

* Ensimmäinen versio

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
