# विस्तारित विनआम (extendedWinamp) #

* लेखकहरू: हरभोजकातिक र नेत्रवाणी-थपसाधन-समूह
* डाउनलोड: [version 1.2][1]

यो विस्तारित appModule ले नेत्रवाणीमा पाइने प्रारम्भिक Winamp appModule को
थप कार्य क्षमता विस्तार गर्छ ।

* s ले हेरफेर फेरिन्छ ।
* r ले दोहोर्याउने कार्य फेरिन्छ ।
* F5 पृष्ठध्वनी मौन राख ।
* F6: पृष्टध्वनीलाई २५% आयतनमा कायम गर ।
* F7 पृष्टध्वनीलाई ५0% आयतनमा कायम गर ।
* F8 पृष्टध्वनीलाई 100% आयतनमा कायम गर ।
* Shift+LeftArrow pan Left
* Shift+RightArrow pan Right
* Shift+UpArrow pan Center
* Control+Shift+t कूल ट्याक लम्बाई बताउछ ।
* Control+Shift+e speaks track Elapsed Time
* Control+Shift+r speaks track Remaining Time
* Shift+r Review the end of track "last 6 seconds by default"
* Control+r Set the review time "in seconds" for use with Review End of
  Track command
* Shift+j Set alternate jump time "in seconds"
* Control+RightArrow alternate Jump Forward "6 seconds by default"
* Control+LeftArrow alternate Jump Backward "6 seconds by default"

## १.१ मा गरिएका रिवर्तनहरू ##

* नयाँ भाषाहरू: अरगानिज, अरबी, डच, जर्मनी, फिनिस, फ्रानसेली, ग्यालिसियन,
  हङ्गेरियाली, इडालियन, जापानी, कोरियाली, नेपाली, पुर्तगाली(ब्राजेली), रुसी,
  स्लोभाकेली, स्लोभिनियन, स्पेनीस, तामिल, तुर्की

## १.० मा गरिएका परिवर्तनहरू ##

* प्रारम्भिक प्रकासन

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
