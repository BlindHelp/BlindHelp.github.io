# extendedWinamp #

* Autores: Hrvoje Katic y l'equipo de complementos de NVDA
* Baixada: [versión 1.2][1]

Iste modulo estendillau enampla o modulo  orichinal pa Winamp que se troba
en NVDA con beluna funcionalidat extra.

* s enchegar u desenchegar l'orden aleatorio
* r enchegar u desenchegar o repetir
* F5 silenciar a reproducción
* F6 fixar o volumen d'a reproducción ta lo 25%
* F7 fixar o volumen d'a reproducción ta lo 50%
* F8 fixar o volumen d'a reproducción ta lo 100%
* Mayus+Flecha Cucha Valanz a la cucha
* Mayus+Flecha Dreita Valanz a la Dreita
* Mayus+Flecha Alto Valanz a lo Centro
* Control+Mayus+t Charra lo total d'a durada d'a Pista
* Control+Mayus+e Charra lo Tiempo Transcurriiu d'a Pista
* Control+Mayus+r Charra lo Tiempo Restant d'a Pista
* Mayus+r Revisar o final d'a pista "zaguers 6 segundos por omisión"
* Control+r fixa lo tiempo de revisión "en segundos" pa fer-lo servir con a
  orden Revisar o final d'a Pista
* Mayus+j Achusta lo tiempo de blinco alternativo "en segundos"
* Control+Flecha Dreita Blinco Alternativo enta devant "6 segundos por
  omisión"
* Control+Flecha Cucha Blinco Alternativo enta zaga "6 segundos por omisión"

## Cambios en 1.1 ##

* Nuevos idiomas: Alemán, arabe, Aragonés, Coreano, Eslovaco, Esloveno,
  Espanyol, Finlandés, Francés, Gallego, Holandés, Hungaro, Italiano,
  chaponés, Nepalí, Portugués (Brasil), Ruso, Tamil, Turco.

## Cambios en 1.0 ##

* Versión inicial

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
