# extendedWinamp #

* Autori: Hrvoje Katic e il Team componenti aggiuntivi NVDA
* Download: [version 1.2][1]

Questo componente aggiuntivo integra alcune funzioni migliorative al modulo
Winamp già presente in NVDA.

* s commuta casuale on/off
* r Commuta ripetizione  on/off
* F5 riproduzione mute
* F6 Volume riproduzione impostato al 25%
* f7 imposta volume riproduzione al 50%
* f8 imposta volume riproduzione al 100%
* Shift+FrecciaSinistra pan Sinistra
* Shift+FrecciaDestra pan Destra
* Shift+FrecciaSu pan centrale
* Control+Shift+t annuncia durata totale traccia
* Control+Shift+e annuncia tempo trascorso traccia
* Control+Shift+r annuncia tempo rimanente traccia
* Shift+r revisione fine traccia "gli ultimi sei secondi da impostazioni
  predefinite"
* Control+r Imposta il tempo revisione "in secondi" per uso con comando
  Review fine traccia
* Shift+j Imposta salto temporale "in secondi"
* Control+frecciaDestra Alterna salto avanti "6 secondi da impostazioni
  predefinite"
* Control+frecciaSinistra Alterna salto indietro "6 secondi da impostazioni
  predefinite"

## Cambiamenti per la 1.1 ##

* Nuove lingue: aragonese, arabo, olandese, tedesco, finlandese, francese,
  galiziano, ungherese, italiano, giapponese, coreano, nepalese, portoghese
  (brasiliano), russo, slovacco, sloveno, spagnolo, tamil, turco.

## Cambiamenti per la 1.0 ##

* Prima versione

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
