# extendedWinamp #

* Autores: Hrvoje Katic e time de complementos do NVDA
* Baixe: [versão 1.2][1]

Este módulo estendido acrescenta funções extras ao módulo original para
Winamp que vem com o NVDA.

* s liga/desliga reprodução aleatória
* r liga/desliga repetição
* F5 silencia reprodução
* F6 coloca volume de reprodução em 25%
* F7 coloca volume de reprodução em 50%
* F8 coloca volume de reprodução em 100%
* Shift+SetaEsquerda balanço a esquerda
* Shift+SetaDireita balanço a direita
* Shift+SetaCima balanço no centro
* Control+Shift+t fala duração total da faixa
* Control+Shift+e fala tempo decorrido da faixa
* Control+Shift+r fala tempo restante da faixa
* Shift+r toca fim da faixa "últimos 6 segundos por padrão"
* Control+r configura tempo de revisão "em segundos" para uso com o comando
  toca fim da faixa
* Shift+j configura tempo alternativo de salto "em segundos"
* Control+RightArrow salto alternativo para frente "6 segundos por padrão"
* Control+LeftArrow salto alternativo para trás "6 segundos por padrão"

## Mudanças na 1.1 ##

* Novos idiomas: Alemão, Aragonês, Árabe, Coreano, Eslovaco, Esloveno,
  Espanhol, Finlandês, Francês, Galego, Holandês, Húngaro, Italiano,
  Japonês, Nepalês, Português do Brasil, Russo, Tâmil, Turco.

## Mudanças na 1.0 ##

* Versão inicial

[[!tag stable]]

[1]: https://github.com/beqabeqa473/extendedWinamp/releases/download/v1.2/extendedWinamp-v1.2.nvda-addon
