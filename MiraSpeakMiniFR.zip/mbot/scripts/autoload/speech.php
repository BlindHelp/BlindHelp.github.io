<?php
function mbot_load(){
		mb_SelfRegister(MB_EVENT_MSG_IN,0);
		mb_SelfRegister(MB_EVENT_MSG_OUT,0);

  mb_SelfRegister(MB_EVENT_NEW_CSTATUS,1);
# mb_SoundAdd("away","none","./sounds/status/away.wav");
# mb_SoundAdd("lunch","none","./sounds/status/lunch.wav");
# mb_SoundAdd("na","none","./sounds/status/na.wav");
# mb_SoundAdd("phone","none","./sounds/status/phone.wav");
# mb_SoundAdd("offline","none","./sounds/status/offline.wav");
# mb_SoundAdd("occupied","none","./sounds/status/occupied.wav");
}
function mbe_MsgIn($cid,$body,$timestamp,$known){
  $name = mb_CGetDisplayName($cid);
$mbody=str_replace("\r\n",". ",$body);
$mbody=str_replace("í","�",$mbody);
$mbody=str_replace("�"," ",$mbody);
$mbody=str_replace("é","e",$mbody);
$mbody=str_replace("ñ", "�", $mbody);
$mbody=str_replace("ó","�",$mbody);
$mbody=str_replace("á","�",$mbody);
$mbody=str_replace("ú","�",$mbody);
$mbody=str_replace("ç","�",$mbody);
$mbody=str_replace("é","�",$mbody);

$socket=	fsockopen("127.0.0.1", 31337);
fwrite($socket,$name .": " .$mbody ."\r\n");
fclose($socket);
}
function mbe_CStatus($cid, $known, $module, $setting, $val_type, $value)
{
 $name = mb_CGetDisplayName($cid);
if ($value == 40071) {
# mb_SoundPlay("offline");
$socket=	fsockopen("127.0.0.1", 31337);
fwrite($socket,mb_cgetproto($cid).": ".$name ." s'est d�connect�.\r\n");
fclose($socket);

}
if ($value == 40072) {
$socket=	fsockopen("127.0.0.1", 31337);
fwrite($socket,mb_cgetproto($cid).": ".$name ." s'est connect�.\r\n");
fclose($socket);

}
# if ($value == 40073) {
# mb_SoundPlay("na");
# $socket=	fsockopen("127.0.0.1", 31337);
# fwrite($socket,mb_cgetproto($cid).": ".$name ."'s status is now not available.\r\n");
# fclose($socket);

# }
if ($value == 40075) {
# mb_SoundPlay("away");
$socket=	fsockopen("127.0.0.1", 31337);
fwrite($socket,mb_cgetproto($cid).": ".$name ." est maintenant absent.\r\n");
fclose($socket);

}
if ($value == 40076) {
# mb_SoundPlay("occupied");
$socket=	fsockopen("127.0.0.1", 31337);
fwrite($socket,mb_cgetproto($cid).": ".$name ." est maintenant ocupp�.\r\n");
fclose($socket);

}
# if ($value == 40079) {
# mb_SoundPlay("phone");
# $socket=	fsockopen("127.0.0.1", 31337);
# fwrite($socket,mb_cgetproto($cid).": ".$name ." is now on the phone.\r\n");
# fclose($socket);

# }
if ($value == 40080) {
# mb_SoundPlay("lunch")$socket=	fsockopen("127.0.0.1", 31337);
fwrite($socket,mb_cgetproto($cid).": ".$name ."est parti manger.\r\n");
fclose($socket);

}
  return 1; //there is no need to let others notify again..
}
function mbe_MsgOut($cid,$body) {
$mbody=str_replace("\r\n",". ",$body);
$mbody=str_replace("í","�",$mbody);
$mbody=str_replace("�"," ",$mbody);
$mbody=str_replace("á","�",$mbody);
$mbody=str_replace("��","�",$mbody);
$mbody=str_replace("��","�",$mbody);
$mbody=str_replace("ñ", "�", $mbody);
$mbody=str_replace("é","�",$mbody);
$mbody=str_replace("ç","�",$mbody);
$mbody=str_replace("ê","�",$mbody);
$mbody=str_replace("î","�",$mbody);
$mbody=str_replace("â","�",$mbody);
$mbody=str_replace("�","�",$mbody);
$mbody=str_replace("��","�",$mbody);
$mbody=str_replace("��","�",$mbody);
$mbody=str_replace("��","�",$mbody);
$mbody=str_replace("��","�",$mbody);
$mbody=str_replace("&","�",$mbody);
$mbody=str_replace("��","�",$mbody);
$mbody=str_replace("��","�",$mbody);
$mbody=str_replace("�","�",$mbody);
$mbody=str_replace("�","�",$mbody);

$socket=	fsockopen("127.0.0.1", 31337);
fwrite($socket,$mbody ."\r\n");
fclose($socket);
}
?>
